"""Arma el prototipo (los cinco temas) en una sola página: prototipo/index.html. Uso: python prototipo/build.py"""
import re
from pathlib import Path

HERE = Path(__file__).parent
P = HERE / "parts"

ARR = ('<svg class="arr" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" '
       'stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>')
GO = ('<svg class="f-el__go" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4.5 11.5l7-7M6 4.5h5.5V10" '
      'stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>')
CHECK = ('<svg class="x-ok" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" '
         'stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>')
TO = ('<svg class="x-to" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3 8h10M9 4l4 4-4 4" '
      'stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>')
OK = ('<svg class="k-ok" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M3.5 8.5l3 3 6-7" '
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>')
ICONS = ('<svg class="i-pause" viewBox="0 0 16 16" aria-hidden="true"><rect x="4" y="3" width="2.6" height="10" rx="1" fill="currentColor"/>'
         '<rect x="9.4" y="3" width="2.6" height="10" rx="1" fill="currentColor"/></svg>'
         '<svg class="i-play" viewBox="0 0 16 16" aria-hidden="true"><path d="M5 3.2v9.6a.6.6 0 0 0 .9.5l7.6-4.8a.6.6 0 0 0 0-1L5.9 2.7a.6.6 0 0 0-.9.5z" fill="currentColor"/></svg>')


def pause(extra=""):
    cls = ("pause " + extra).strip()
    return f'<button class="{cls}" type="button" aria-label="Pausar animación">{ICONS}</button>'


LINKS = ('<nav class="nav__links" aria-label="Principal"><a href="#servicios">Servicios</a>'
         '<a href="#proyectos">Proyectos</a><a href="#redes">Redes</a><a href="#contacto">Contacto</a></nav>')


def nav(kind):
    cls = {"std": "nav", "center": "nav nav--center", "dark": "nav nav--dark", "darkc": "nav nav--dark nav--center"}[kind]
    logo = "logo logo--dark" if kind.startswith("dark") else "logo"
    btn = {"std": "btn--ink", "center": "btn--ink", "dark": "btn--white", "darkc": "btn--white"}[kind]
    return (f'<header class="{cls}"><a class="nav__home" href="#top" aria-label="CaSe Studio, inicio">'
            f'<svg class="{logo}" aria-hidden="true"><use href="#logo-cut"></use></svg></a>{LINKS}'
            '<div class="nav__end"><div class="nav__lang" role="group" aria-label="Idioma"><button type="button" data-lang="es" aria-pressed="true" aria-label="Español">ES</button>'
            '<button type="button" data-lang="en" aria-pressed="false" aria-label="English">EN</button></div>'
            f'<a class="btn btn--sm {btn}" href="#contacto">Empezar mi proyecto</a></div></header>')


STRIP = ('<div class="strip"><p class="strip__t">Proyectos recientes</p><ul class="strip__l" aria-label="Clientes de ejemplo">'
         '<li class="wm wm--serif">Café Altura</li><li class="wm wm--caps">CLÍNICA NORTE</li><li class="wm wm--ital">Hotel Marea</li>'
         '<li class="wm wm--wide">SELVA</li><li class="wm wm--soft">lúa</li></ul></div>')


def card(t, e):
    return f'<div class="ms__card"><span></span><strong>{t}</strong><em>{e}</em></div>'


MS = {
    "cafe": ('<div class="ms ms--cafe"><div class="ms__nav"><b>Café Altura</b><i>Menú</i><i>Ubicación</i><span class="ms__btn">Pedir</span></div>'
             '<div class="ms__hero"><h4>Café de especialidad, tostado cada semana</h4><p>Desayunos, granos para llevar y pedidos a domicilio en el barrio.</p>'
             '<div class="ms__acts"><span class="ms__btn">Pedir por WhatsApp</span><span class="ms__btn ms__btn--line">Ver el menú</span></div></div>'
             '<div class="ms__row">' + card("Capuchino", "Leche entera o de avena") + card("Pan de masa madre", "Sale del horno a las 7")
             + card("Granola de la casa", "Bolsa de 500 g") + '</div></div>'),
    "clinica": ('<div class="ms ms--clinica"><div class="ms__nav"><b>Clínica Norte</b><i>Especialidades</i><i>Sedes</i><span class="ms__btn">Pedir cita</span></div>'
                '<div class="ms__hero"><h4>Pide tu cita sin llamar</h4><p>Elige especialidad, sede y hora desde el celular.</p>'
                '<div class="ms__acts"><span class="ms__btn">Pedir cita</span><span class="ms__btn ms__btn--line">Ver especialidades</span></div></div>'
                '<div class="ms__chips"><span class="on">Medicina general</span><span>Pediatría</span><span>Odontología</span><span>Laboratorio</span></div>'
                '<div class="ms__img"><b>Norte</b></div></div>'),
    "hotel": ('<div class="ms ms--hotel"><div class="ms__nav"><b>Hotel Marea</b><i>Habitaciones</i><i>Restaurante</i><span class="ms__btn">Reservar</span></div>'
              '<div class="ms__hero"><h4>Doce habitaciones frente al mar</h4><p>Desayuno incluido y reserva directa en este sitio.</p></div>'
              '<div class="ms__img"><b>Marea</b></div>'
              '<div class="ms__row">' + card("Suite Horizonte", "Vista al mar y terraza") + card("Doble Bahía", "Dos camas y balcón")
              + card("Familiar Arena", "Hasta cuatro personas") + '</div></div>'),
    "selva": ('<div class="ms ms--selva"><div class="ms__nav"><b>Selva</b><i>Mujer</i><i>Hombre</i><i>Lino</i><span class="ms__btn">Bolsa</span></div>'
              '<div class="ms__img"><b>Lino</b></div>'
              '<div class="ms__hero"><h4>Colección de lino para clima cálido</h4><p>Envíos a todo el país y cambios en 30 días.</p></div>'
              '<div class="ms__row">' + card("Camisa Brisa", "Cuatro colores") + card("Pantalón Delta", "Corte recto")
              + card("Vestido Lluvia", "Hasta el tobillo") + '</div></div>'),
    "lua": ('<div class="ms ms--lua"><div class="ms__nav"><b>Lúa</b><i>Rutinas</i><i>Productos</i><span class="ms__btn">Comprar</span></div>'
            '<div class="ms__hero"><h4>Tu rutina de noche en tres pasos</h4><p>Limpiador, sérum y crema para piel mixta.</p>'
            '<div class="ms__acts"><span class="ms__btn">Armar mi rutina</span></div></div>'
            '<div class="ms__chips"><span class="on">Piel mixta</span><span>Piel seca</span><span>Piel sensible</span></div>'
            '<div class="ms__row">' + card("Limpiador", "Paso 1") + card("Sérum", "Paso 2") + card("Crema de noche", "Paso 3") + '</div></div>'),
}

OLD = ('<div class="ms ms--old"><div class="ms__nav"><b>CLÍNICA NORTE</b><i>Inicio</i><i>Quiénes somos</i><i>Servicios</i><i>Contáctenos</i></div>'
       '<div class="old-ban">¡¡ BIENVENIDOS A NUESTRA PÁGINA WEB !!</div><h4>Clínica Norte, su salud es lo primero</h4>'
       '<div class="old-cols"><div class="old-box">Foto</div><div><p>Somos una institución dedicada al cuidado de la salud de toda la familia, '
       'con profesionales en distintas especialidades.</p><p>Para solicitar una cita comuníquese en horario de oficina de lunes a viernes.</p>'
       '<p><u>Descargue nuestro portafolio de servicios (PDF)</u></p></div></div></div>')
NEW = ('<div class="ms ms--clinica"><div class="ms__nav"><b>Clínica Norte</b><i>Especialidades</i><i>Sedes</i><i>Resultados</i><span class="ms__btn">Pedir cita</span></div>'
       '<div class="a-grid"><div class="ms__hero"><h4>Pide tu cita sin llamar</h4><p>Elige especialidad, sede y hora desde el celular. Te confirmamos por WhatsApp.</p>'
       '<div class="ms__acts"><span class="ms__btn">Pedir cita</span><span class="ms__btn ms__btn--line">Ver especialidades</span></div></div>'
       '<div class="a-sedes"><strong>Sedes y horarios</strong><p><b>Sede Norte</b><span>Lunes a sábado, 7:00 a 19:00</span></p>'
       '<p><b>Sede Centro</b><span>Lunes a viernes, 7:00 a 17:00</span></p></div></div>'
       '<div class="ms__chips"><span class="on">Medicina general</span><span>Pediatría</span><span>Odontología</span><span>Laboratorio</span></div>'
       '<div class="ms__img"><b>Norte</b></div></div>')


SV_ITEMS = [("Sitios web", "Páginas que cargan rápido, se leen bien en el celular y llevan a tu cliente a escribirte o a comprar."),
            ("Tiendas en línea", "Catálogo, carrito y pagos conectados con el inventario que ya manejas."),
            ("Redes sociales", "Calendario del mes, fotos, videos y textos listos para publicar."),
            ("Marca", "Logo, colores y tipografías con una guía corta para usarlos en todo lo que publiques.")]


def services(theme):
    lis = "".join(f'<li><button class="sv-it" type="button"><span class="mono">0{i + 1}</span><strong>{t}</strong></button></li>' for i, (t, _) in enumerate(SV_ITEMS))
    ds = "".join(f'<p class="sv-d">{d}</p>' for _, d in SV_ITEMS)
    return (f'<section class="moment sv sv--{theme}" id="servicios" aria-labelledby="sv-h" style="--mh:440vh"><div class="moment__stick sv-stick">'
            f'<div class="sv-left"><h2 class="h2 sv-h" id="sv-h">Lo que hacemos por tu marca</h2><ol class="sv-list">{lis}</ol><div class="sv-ds">{ds}</div></div>'
            '<div class="sv-vis" aria-hidden="true"><canvas class="sv-cv"></canvas><span class="sv-n mono">01 / 04</span></div>'
            '</div></section>')


DK_ITEMS = [("Tu negocio y tus clientes", "Conversamos", "Entendemos tu negocio, tus clientes y qué debe lograr la web."),
            ("Estilo y estructura", "Diseñamos", "Proponemos el estilo y la estructura antes de programar."),
            ("Rápido y adaptado a celulares", "Construimos", "Desarrollamos un sitio rápido y adaptado a celulares."),
            ("Seguimos contigo", "Lanzamos", "Publicamos, te enseñamos a usarlo y seguimos contigo.")]


def deck(theme):
    cards = "".join(f'<li class="dk-card"><div class="dk-top"><span class="dk-num" aria-hidden="true">0{i + 1}</span><span class="dk-chip mono">{c}</span></div>'
                    f'<div><h3>{t}</h3><p>{d}</p></div></li>' for i, (c, t, d) in enumerate(DK_ITEMS))
    return (f'<section class="moment dk dk--{theme}" id="proceso" aria-labelledby="dk-h" style="--mh:420vh"><div class="moment__stick dk-stick is-flow">'
            '<div class="dk-left"><h2 class="h2" id="dk-h">Así trabajamos contigo</h2><p class="lead">Cuatro pasos, de la primera conversación al sitio publicado.</p>'
            '<div class="dk-steps" aria-hidden="true"><i></i><i></i><i></i><i></i></div></div>'
            f'<ol class="dk-stack">{cards}</ol></div></section>')


def portfolio(theme):
    return (f'<section class="moment pf pf--{theme}" id="proyectos" aria-labelledby="pf-h" style="--mh:560vh"><div class="moment__stick pf-stick">'
            '<div class="pf-left"><h2 class="h2" id="pf-h">Proyectos</h2><ol class="pf-list"></ol>'
            f'<button class="btn btn--sm {"btn--ink" if theme == "tarj" else "btn--white"} pf-open" type="button">Abrir vista previa {ARR}</button></div>'
            '<div class="pf-right"><button class="pf-frame" type="button"><span class="pf-bar" aria-hidden="true"><i></i><i></i><i></i><span class="pf-url mono"></span></span>'
            f'<span class="pf-view"><span class="pf-cur" aria-hidden="true">Abrir vista previa {ARR}</span></span></button></div></div></section>')


def fill(s):
    s = re.sub(r"\{\{PORTFOLIO:(\w+)\}\}", lambda m: portfolio(m.group(1)), s)
    s = re.sub(r"\{\{SERVICES:(\w+)\}\}", lambda m: services(m.group(1)), s)
    s = re.sub(r"\{\{DECK:(\w+)\}\}", lambda m: deck(m.group(1)), s)
    s = s.replace("{{NAV}}", nav("std")).replace("{{NAV_CENTER}}", nav("center")).replace("{{NAV_DARK}}", nav("dark")).replace("{{NAV_DARKC}}", nav("darkc"))
    s = s.replace("{{STRIP}}", STRIP)
    s = s.replace("{{ARR}}", ARR).replace("{{GO}}", GO).replace("{{CHECK}}", CHECK).replace("{{TO}}", TO).replace("{{OK}}", OK)
    s = s.replace("{{PAUSE_DARK}}", pause("pause--dark")).replace("{{PAUSE}}", pause())
    s = re.sub(r"\{\{PAUSE:([\w\- ]+)\}\}", lambda m: pause(m.group(1)), s)
    s = re.sub(r"\{\{MS:(\w+)\}\}", lambda m: MS[m.group(1)], s)
    s = s.replace("{{OLD}}", OLD).replace("{{NEW}}", NEW)
    left = re.findall(r"\{\{[^}]*\}\}", s)
    assert not left, left
    return s


def main():
    head = (P / "00-head.html").read_text(encoding="utf-8")
    order = ["logo.html", "02-shared.html"] + sorted(f.name for f in P.glob("h[0-9][0-9]-*.html")) + sorted(f.name for f in P.glob("k[0-9][0-9]-*.html")) + ["zz-harness.html"]
    styles, body = [], []
    for name in order:
        part = fill((P / name).read_text(encoding="utf-8"))
        styles += re.findall(r"<style>.*?</style>", part, flags=re.S)
        body.append(re.sub(r"<style>.*?</style>\s*", "", part, flags=re.S))
    head = head.replace("</head>", "\n".join(styles) + "\n</head>")
    html = head + "\n<body>\n" + "\n".join(body)
    (HERE / "index.html").write_text(html, encoding="utf-8", newline="\n")
    print(f"index.html: {len(html) / 1024:.1f} KB, {len(order) - 3} variants")


if __name__ == "__main__":
    main()
