"""Variation geometry. Every variant returns (layers, W, H); layers = [(role, d)], where role is
'fg' (ink or paper), 'accent' (brand blue) or 'white' (always white, on an accent tile)."""
import math
import sys
sys.path.insert(0, "/home/claude/case/tools")
import marks as M

f = M.f


# ------------------------------------------------------------------ helpers
def poly_d(pts):
    return "M" + "L".join(f"{f(x)} {f(y)}" for x, y in pts) + "Z"


def rrect_poly(x, y, w, h, r, seg=48):
    pts = []
    for cx, cy, a0 in ((x + w - r, y + r, -90), (x + w - r, y + h - r, 0),
                       (x + r, y + h - r, 90), (x + r, y + r, 180)):
        for i in range(seg + 1):
            a = math.radians(a0 + 90 * i / seg)
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def clip(poly, nx, ny, c):
    """Keep the part of poly where nx*x + ny*y <= c (Sutherland-Hodgman)."""
    out = []
    n = len(poly)
    for i in range(n):
        p, q = poly[i], poly[(i + 1) % n]
        dp, dq = nx * p[0] + ny * p[1] - c, nx * q[0] + ny * q[1] - c
        if dp <= 0:
            out.append(p)
        if (dp < 0) != (dq < 0) and dp != dq:
            t = dp / (dp - dq)
            out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
    return out


def move(pts, dx, dy):
    return [(x + dx, y + dy) for x, y in pts]


def bbox(polys):
    xs = [x for p in polys for x, _ in p]
    ys = [y for p in polys for _, y in p]
    return min(xs), min(ys), max(xs), max(ys)


def c_piece(cx, cy, R, t, L, rc, round_end=False):
    """Outline of a C-shaped stroke: top stub, left side with corner radius rc (rc=R: a
    semicircle), bottom end at (cx, cy+R). Butt ends. Counter-clockwise on screen."""
    h = t / 2
    ro, ri = rc + h, max(rc - h, 0)
    xl = cx - R
    d = (f"M{f(cx + L)} {f(cy - R - h)}H{f(xl + rc)}"
         f"A{f(ro)} {f(ro)} 0 0 0 {f(xl - h)} {f(cy - R + rc)}V{f(cy + R - rc)}"
         f"A{f(ro)} {f(ro)} 0 0 0 {f(xl + rc)} {f(cy + R + h)}H{f(cx)}V{f(cy + R - h)}"
         f"H{f(xl + rc)}A{f(ri)} {f(ri)} 0 0 1 {f(xl + h)} {f(cy + R - rc)}V{f(cy - R + rc)}"
         f"A{f(ri)} {f(ri)} 0 0 1 {f(xl + rc)} {f(cy - R + h)}H{f(cx + L)}")
    if round_end:
        d += f"A{f(h)} {f(h)} 0 0 0 {f(cx + L)} {f(cy - R - h)}"
    return d + "Z"


def xform_path(d, ox, oy, k):
    """Uniformly scale by k then translate by (ox, oy) a path of M/H/V/A/L/Z commands."""
    import re
    toks = re.findall(r"[MHVALZ]|-?\d+(?:\.\d+)?", d)
    out, i, cmd = [], 0, None
    while i < len(toks):
        tk = toks[i]
        if tk in "MHVALZ":
            cmd = tk
            i += 1
            if cmd == "Z":
                out.append("Z")
            continue
        if cmd in "ML":
            x, y = float(toks[i]), float(toks[i + 1]); i += 2
            out.append(f"{cmd}{f(x * k + ox)} {f(y * k + oy)}")
        elif cmd == "H":
            out.append(f"H{f(float(tk) * k + ox)}"); i += 1
        elif cmd == "V":
            out.append(f"V{f(float(tk) * k + oy)}"); i += 1
        elif cmd == "A":
            rx, ry, rot, la, sw, x, y = toks[i:i + 7]; i += 7
            out.append(f"A{f(float(rx) * k)} {f(float(ry) * k)} {rot} {la} {sw} "
                       f"{f(float(x) * k + ox)} {f(float(y) * k + oy)}")
    return "".join(out)


# ------------------------------------------------------------------ Dos piezas
def dos_base(t=17.0, R=21.0, gap=5.0, rc=None, dx=0.0, round_end=False):
    """Two identical C pieces; the second is the first rotated 180deg about the box centre.
    gap: horizontal slit; dx: extra horizontal stagger. Returns (top_d, bottom_d, W, H)."""
    rc = R if rc is None else rc
    L = R * 0.95
    W = 2 * R + t + gap + 2 * dx + (t if round_end else 0) * 0
    H = 4 * R + t
    cx, cy = t / 2 + R, t / 2 + R
    top = c_piece(cx, cy, R, t, L - (t / 2 if round_end else 0), rc, round_end)
    # rotated copy: rebuild by mapping coordinates (x, y) -> (W - x, H - y)
    bot = _rot_path(top, W, H)
    return top, bot, W, H


def _rot_path(d, W, H):
    """Rotate a path made of M/H/V/A/L/Z commands by 180deg inside a W x H box."""
    import re
    toks = re.findall(r"[MHVALZ]|-?\d+(?:\.\d+)?", d)
    out, i, cmd = [], 0, None
    while i < len(toks):
        tk = toks[i]
        if tk in "MHVALZ":
            cmd = tk
            i += 1
            if cmd == "Z":
                out.append("Z")
            continue
        if cmd in "ML":
            x, y = float(toks[i]), float(toks[i + 1]); i += 2
            out.append(f"{cmd}{f(W - x)} {f(H - y)}")
        elif cmd == "H":
            out.append(f"H{f(W - float(tk))}"); i += 1
        elif cmd == "V":
            out.append(f"V{f(H - float(tk))}"); i += 1
        elif cmd == "A":
            rx, ry, rot, la, sw, x, y = toks[i:i + 7]; i += 7
            out.append(f"A{rx} {ry} {rot} {la} {sw} {f(W - float(x))} {f(H - float(y))}")
    return "".join(out)


def v_dos_original():
    a, b, W, H = dos_base()
    return [("fg", a + b)], W, H


def v_dos_suave():
    a, b, W, H = dos_base(t=19.0, round_end=True)
    return [("fg", a + b)], W, H


def v_dos_cuadrada():
    a, b, W, H = dos_base(rc=11.0, gap=5.0)
    return [("fg", a + b)], W, H


def v_dos_bicolor():
    a, b, W, H = dos_base()
    return [("fg", a), ("accent", b)], W, H


def v_dos_sello():
    a, b, W, H = dos_base(gap=5.0)
    D = 100.0
    s = 0.62 * D / H
    ox, oy = (D - W * s) / 2, (D - H * s) / 2
    circle = "M50 0A50 50 0 0 1 50 100A50 50 0 0 1 50 0Z"   # clockwise; pieces run the other way
    return [("fg", circle + xform_path(a + b, ox, oy, s))], D, D


# ------------------------------------------------------------------ Cursor
def _caret(x, top, bot, w, round_ends=False):
    if not round_ends:
        return f"M{f(x)} {f(top)}h{f(w)}V{f(bot)}h{f(-w)}Z"
    r = w / 2
    return (f"M{f(x)} {f(top + r)}A{f(r)} {f(r)} 0 0 1 {f(x + w)} {f(top + r)}V{f(bot - r)}"
            f"A{f(r)} {f(r)} 0 0 1 {f(x)} {f(bot - r)}Z")


def cursor_geo(t=19.0, open_deg=46.0, caret_w=11.5, ext=7.0, cut="ray", round_ends=False):
    Ro, Ri = 50.0, 50.0 - t
    cx, cy = 50.0, 50.0 + ext
    H = 100.0 + 2 * ext
    if cut == "ray":
        a = math.radians(open_deg)
        o1 = (cx + Ro * math.cos(a), cy - Ro * math.sin(a))
        o2 = (cx + Ro * math.cos(a), cy + Ro * math.sin(a))
        i1 = (cx + Ri * math.cos(a), cy - Ri * math.sin(a))
        i2 = (cx + Ri * math.cos(a), cy + Ri * math.sin(a))
    else:  # horizontal cut at +-hc
        hc = Ri * 0.80
        o1 = (cx + math.sqrt(Ro ** 2 - hc ** 2), cy - hc)
        o2 = (cx + math.sqrt(Ro ** 2 - hc ** 2), cy + hc)
        i1 = (cx + math.sqrt(Ri ** 2 - hc ** 2), cy - hc)
        i2 = (cx + math.sqrt(Ri ** 2 - hc ** 2), cy + hc)
    if round_ends:
        r = t / 2
        ring = (f"M{f(o1[0])} {f(o1[1])}A{f(Ro)} {f(Ro)} 0 1 0 {f(o2[0])} {f(o2[1])}"
                f"A{f(r)} {f(r)} 0 0 0 {f(i2[0])} {f(i2[1])}"
                f"A{f(Ri)} {f(Ri)} 0 1 1 {f(i1[0])} {f(i1[1])}"
                f"A{f(r)} {f(r)} 0 0 0 {f(o1[0])} {f(o1[1])}Z")
    else:
        ring = (f"M{f(o1[0])} {f(o1[1])}A{f(Ro)} {f(Ro)} 0 1 0 {f(o2[0])} {f(o2[1])}"
                f"L{f(i2[0])} {f(i2[1])}A{f(Ri)} {f(Ri)} 0 1 1 {f(i1[0])} {f(i1[1])}Z")
    x = cx + Ri + (Ro - Ri - caret_w) / 2 + 3
    if cut != "ray":
        x = o1[0] + 5.0
    car = _caret(x, 0.0, H, caret_w, round_ends)
    W = max(100.0, x + caret_w)
    return ring, car, W, H


def v_cur_original():
    ring, car, W, H = cursor_geo()
    return [("fg", ring), ("accent", car)], W, H


def v_cur_redonda():
    ring, car, W, H = cursor_geo(round_ends=True, open_deg=50)
    return [("fg", ring), ("accent", car)], W, H


def v_cur_recta():
    ring, car, W, H = cursor_geo(cut="flat")
    return [("fg", ring), ("accent", car)], W, H


def v_cur_ligera():
    ring, car, W, H = cursor_geo(t=12.0, caret_w=8.0, open_deg=42, ext=8.0)
    return [("fg", ring), ("accent", car)], W, H


def v_cur_seleccion():
    ring, car, W, H = cursor_geo()
    D = 100.0
    s = 0.56 * D / H
    ox, oy = (D - W * s) / 2 + 1.5, (D - H * s) / 2
    tile = "M22.5 0H77.5A22.5 22.5 0 0 1 100 22.5V77.5A22.5 22.5 0 0 1 77.5 100H22.5A22.5 22.5 0 0 1 0 77.5V22.5A22.5 22.5 0 0 1 22.5 0Z"
    return [("accent", tile), ("white", ring + car, (ox, oy, s))], D, D


# ------------------------------------------------------------------ Ruta
def ruta_pieces(cuts, angle=67.0, r=None, shift=0.0):
    """cuts: list of (offset_along_normal, width). Returns list of polygons, left to right."""
    th = math.radians(angle)
    nx, ny = math.sin(th), math.cos(th)            # normal (to the lower-right)
    ux, uy = math.cos(th), -math.sin(th)           # along the slash (up-right)
    c0 = nx * 50 + ny * 50
    if r is None:
        r = M.ruta_path()[0] and 22.8
    base = rrect_poly(0, 0, 100, 100, r)
    edges = sorted(cuts)
    polys = []
    lo = None
    for off, w in edges + [(None, None)]:
        p = base
        if lo is not None:
            p = clip(p, -nx, -ny, -(c0 + lo))      # keep n.x >= c0 + lo
        if off is not None:
            p = clip(p, nx, ny, c0 + off - w / 2)  # keep n.x <= c0 + off - w/2
            lo = off + w / 2
        polys.append(p)
    if shift:
        k = len(polys)
        polys = [move(p, ux * shift * (i - (k - 1) / 2) * 2 / max(k - 1, 1),
                      uy * shift * (i - (k - 1) / 2) * 2 / max(k - 1, 1)) for i, p in enumerate(polys)]
    x0, y0, x1, y1 = bbox(polys)
    polys = [move(p, -x0, -y0) for p in polys]
    return polys, x1 - x0, y1 - y0


def v_ruta_original():
    d, W, H = M.ruta_path()
    return [("fg", d)], W, H


def v_ruta_doble():
    polys, W, H = ruta_pieces([(-8.5, 8.5), (8.5, 8.5)], r=22.8)
    return [("fg", "".join(poly_d(p) for p in polys))], W, H


def v_ruta_desfasada():
    polys, W, H = ruta_pieces([(0.0, 11.0)], r=22.8, shift=6.0)
    return [("fg", "".join(poly_d(p) for p in polys))], W, H


def v_ruta_bicolor():
    polys, W, H = ruta_pieces([(0.0, 11.0)], r=22.8)
    return [("fg", poly_d(polys[0])), ("accent", poly_d(polys[1]))], W, H


def v_ruta_asimetrica():
    polys, W, H = ruta_pieces([(13.0, 10.0)], r=22.8)
    return [("fg", "".join(poly_d(p) for p in polys))], W, H


VARIANTS = {
    "dos": [("original", "Original", v_dos_original), ("suave", "Suave", v_dos_suave),
            ("cuadrada", "Cuadrada", v_dos_cuadrada), ("bicolor", "Bicolor", v_dos_bicolor),
            ("sello", "Sello", v_dos_sello)],
    "cursor": [("original", "Original", v_cur_original), ("redonda", "Redonda", v_cur_redonda),
               ("recta", "Corte recto", v_cur_recta), ("ligera", "Ligera", v_cur_ligera),
               ("seleccion", "Selección", v_cur_seleccion)],
    "ruta": [("original", "Original", v_ruta_original), ("doble", "Doble barra", v_ruta_doble),
             ("desfasada", "Desfasada", v_ruta_desfasada), ("bicolor", "Bicolor", v_ruta_bicolor),
             ("asimetrica", "Asimétrica", v_ruta_asimetrica)],
}


def frag(layers, fg, accent, white="#FFFFFF", bg=None):
    """SVG fragment for a variant's layers. A layer may carry a transform tuple:
    (dx, dy) or (dx, dy, scale)."""
    if bg is None:
        bg = "#FFFFFF" if fg.upper() in ("#0A0A0A", "#000000") else "#0A0A0A"
    col = {"fg": fg, "accent": accent, "white": white, "bg": bg, "hex": "#CA5E"}
    out = []
    for layer in layers:
        role, d = layer[0], layer[1]
        p = f'<path fill="{col[role]}" d="{d}"/>'
        if len(layer) > 2:
            tr = layer[2]
            if len(tr) == 2:
                p = f'<g transform="translate({f(tr[0])} {f(tr[1])})">{p}</g>'
            else:
                p = f'<g transform="translate({f(tr[0])} {f(tr[1])}) scale({tr[2]:.5f})">{p}</g>'
        out.append(p)
    return "".join(out)
