"""Second batch of new concepts. Each returns (layers, W, H); roles as in new.py."""
import math
import sys
sys.path.insert(0, "/home/claude/case/tools")
from marks import f
from new import rrect, rect


def circle(cx, cy, r, ccw=False):
    s = 0 if ccw else 1
    return (f"M{f(cx)} {f(cy - r)}A{f(r)} {f(r)} 0 0 {s} {f(cx)} {f(cy + r)}"
            f"A{f(r)} {f(r)} 0 0 {s} {f(cx)} {f(cy - r)}Z")


def poly(pts):
    return "M" + "L".join(f"{f(x)} {f(y)}" for x, y in pts) + "Z"


def inset(pts, t):
    """Offset a clockwise (on screen) simple polygon inward by t, via edge-line intersections.
    Returns the inner polygon reversed (counter-clockwise) so it cuts a hole under nonzero."""
    n = len(pts)
    lines = []
    for i in range(n):
        (x1, y1), (x2, y2) = pts[i], pts[(i + 1) % n]
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy)
        nx, ny = -dy / L, dx / L          # inward normal for clockwise-on-screen order
        lines.append(((x1 + nx * t, y1 + ny * t), (dx, dy)))
    out = []
    for i in range(n):
        (p, d), (q, e) = lines[i - 1], lines[i]
        den = d[0] * e[1] - d[1] * e[0]
        s = ((q[0] - p[0]) * e[1] - (q[1] - p[1]) * e[0]) / den
        out.append((p[0] + d[0] * s, p[1] + d[1] * s))
    return out[::-1]


# ------------------------------------------------------------ 1. Shift (case-change key)
def shift(t=8.5):
    """The Shift key glyph: an outlined arrow pointing up. It changes the case of letters,
    like the alternating capitals of CaSe."""
    outer = [(50, 0), (100, 50), (73, 50), (73, 100), (27, 100), (27, 50), (0, 50)]
    inner = inset(outer, t)
    return [("fg", poly(outer) + poly(inner))], 100.0, 100.0


# ------------------------------------------------------------ 2. Bézier (pen-tool S)
def _bez(p0, p1, p2, p3, t):
    u = 1 - t
    x = u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0]
    y = u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]
    dx = 3 * u * u * (p1[0] - p0[0]) + 6 * u * t * (p2[0] - p1[0]) + 3 * t * t * (p3[0] - p2[0])
    dy = 3 * u * u * (p1[1] - p0[1]) + 6 * u * t * (p2[1] - p1[1]) + 3 * t * t * (p3[1] - p2[1])
    return x, y, dx, dy


def stroke_bezier(p0, p1, p2, p3, w, n=160):
    left, right = [], []
    for i in range(n + 1):
        x, y, dx, dy = _bez(p0, p1, p2, p3, i / n)
        L = math.hypot(dx, dy) or 1
        nx, ny = -dy / L * w / 2, dx / L * w / 2
        left.append((x + nx, y + ny))
        right.append((x - nx, y - ny))
    return poly(left + right[::-1])


def stroke_line(a, b, w):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy)
    nx, ny = -dy / L * w / 2, dx / L * w / 2
    return poly([(a[0] + nx, a[1] + ny), (b[0] + nx, b[1] + ny), (b[0] - nx, b[1] - ny), (a[0] - nx, a[1] - ny)])


def stroke_arc(cx, cy, r, a0, a1, w, n=90):
    """Outline of a circular arc stroke from angle a0 to a1 (degrees, screen coords)."""
    outer, inner = [], []
    for i in range(n + 1):
        a = math.radians(a0 + (a1 - a0) * i / n)
        outer.append((cx + (r + w / 2) * math.cos(a), cy + (r + w / 2) * math.sin(a)))
        inner.append((cx + (r - w / 2) * math.cos(a), cy + (r - w / 2) * math.sin(a)))
    return outer, inner


def bezier(handles=True, t=11.0, R=18.0, hw=3.4, dot=5.5, anchor=13.0, mid=15.0):
    """An S drawn with the pen tool: two curves meeting at a selected anchor (accent) whose
    straight handle crosses the letter, plus the end anchors."""
    top_c, bot_c = (50.0, 50.0 - R), (50.0, 50.0 + R)
    # top bowl: from the upper-right terminal, round the left side, down to the middle
    o1, i1 = stroke_arc(top_c[0], top_c[1], R, -40, -270, t)
    # bottom bowl: from the middle, round the right side, to the lower-left terminal
    o2, i2 = stroke_arc(bot_c[0], bot_c[1], R, -90, 140, t)
    # join the two strokes into one outline: outer edge of one is the inner edge of the other
    pts = o1 + i2 + o2[::-1] + i1[::-1]
    curve = poly(pts)
    parts = [curve]
    if handles:
        parts.append(stroke_line((50 - 2 * R + 4, 50), (50 + 2 * R - 4, 50), hw))
        parts.append(circle(50 - 2 * R + 4, 50, dot))
        parts.append(circle(50 + 2 * R - 4, 50, dot))
    ends, holes = [], []
    for (cx, cy), a in ((top_c, -40), (bot_c, 140)):
        x, y = cx + R * math.cos(math.radians(a)), cy + R * math.sin(math.radians(a))
        ends.append(rect(x - anchor / 2, y - anchor / 2, anchor, anchor))
        k = anchor - 2 * hw
        holes.append(rect(x - k / 2, y - k / 2, k, k))
    layers = [("fg", "".join(parts))]
    if handles:
        layers += [("fg", "".join(ends)), ("bg", "".join(holes))]
    layers.append(("accent", rect(50 - mid / 2, 50 - mid / 2, mid, mid)))
    return layers, 100.0, 100.0


def bezier_small():
    return bezier(handles=False, t=14.0, mid=18.0)


# ------------------------------------------------------------ 3. Cristal (CaSe lattice)
def cristal(big=13.5, small=7.5):
    """Calcium selenide crystallises in a rock-salt lattice: Ca and Se alternate on a grid,
    the way capitals and small letters alternate in CaSe."""
    out_big, out_small = [], []
    for i in range(3):
        for j in range(3):
            cx, cy = 14 + 36 * i, 14 + 36 * j
            if (i + j) % 2 == 0:
                out_big.append(circle(cx, cy, big))
            else:
                out_small.append(circle(cx, cy, small))
    return [("fg", "".join(out_big)), ("fg", "".join(out_small))], 100.0, 100.0


def cristal_bicolor():
    layers, W, H = cristal()
    return [layers[0], ("accent", layers[1][1])], W, H


# ------------------------------------------------------------ 4. Switch (switch / case)
def switch(gap=7.0):
    """A toggle in the on position. In code, 'case' lives inside a 'switch'."""
    W, H = 100.0, 58.0
    r = H / 2
    track = rrect(0, 0, W, H, r)
    knob_r = r - gap
    hole = circle(W - r, r, knob_r, ccw=True)
    return [("accent", track + hole)], W, H


# ------------------------------------------------------------ 5. Píxel
def pixel(p=28.0, g=8.0, r=4.0, accent=True):
    """A C set on a 3x3 pixel grid; the last pixel placed (top right) is the accent."""
    cells = [(0, 0), (1, 0), (0, 1), (0, 2), (1, 2), (2, 2)]
    ink = "".join(rrect(i * (p + g), j * (p + g), p, p, r) for i, j in cells)
    last = rrect(2 * (p + g), 0, p, p, r)
    if accent:
        return [("fg", ink), ("accent", last)], 100.0, 100.0
    return [("fg", ink + last)], 100.0, 100.0


CONCEPTS2 = [
    ("shift", "Shift", shift, "epilogue"),
    ("bezier", "Bézier", bezier, "bricolage-grotesque"),
    ("cristal", "Cristal", cristal, "ibm-plex-sans"),
    ("switch", "Switch", switch, "urbanist"),
    ("pixel", "Píxel", pixel, "archivo"),
]
