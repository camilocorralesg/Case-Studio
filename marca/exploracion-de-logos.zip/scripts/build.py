"""Build the logo SVG files and the Design-canvas artboards for the three directions."""
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, "/home/claude/case/tools")
from lockup import lockup, mark_frag

INK, PAPER, BLUE = "#0A0A0A", "#FFFFFF", "#3355FF"
GREY = "#EFEFEF"
OUT = "/home/claude/case/logos"
ROOT = "/home/claude/case/canvas"
PROJ = os.path.join(ROOT, "project")
os.makedirs(OUT, exist_ok=True)
os.makedirs(PROJ, exist_ok=True)

DIRS = {
    "dos": {"name": "Dos piezas", "font": "mona-sans", "slug": "dos-piezas"},
    "cursor": {"name": "Cursor", "font": "instrument-sans", "slug": "cursor"},
    "ruta": {"name": "Ruta", "font": "schibsted-grotesk", "slug": "ruta"},
}


def closed(svg):
    """Write <path .../> as <path ...></path> for the canvas parser."""
    return svg.replace('"/>', '"></path>')


def lockup_svg(kind, fg, caret=None, compact=False, cap=100.0):
    fam = DIRS[kind]["font"]
    if compact:
        frag, w, h = lockup(kind, fam, 600, text="CaSe", fill=fg, accent=caret, cap_px=cap)
    else:
        frag, w, h = lockup(kind, fam, 600, text="CaSe", text2="Solutions", weight2=400,
                            fill=fg, accent=caret, cap_px=cap)
    return frag, w, h


def mark_svg(kind, fg, caret=None, small=False):
    k = "dos_solid" if (kind == "dos" and small) else kind
    frag, W, H = mark_frag(k, fg, caret)
    return frag, W, H


def standalone(frag, w, h, pad=0.0, bg=None, title="CaSe Solutions"):
    vb = f"{-pad:.2f} {-pad:.2f} {w + 2 * pad:.2f} {h + 2 * pad:.2f}"
    bgr = f'<rect x="{-pad:.2f}" y="{-pad:.2f}" width="{w + 2 * pad:.2f}" height="{h + 2 * pad:.2f}" fill="{bg}"/>' if bg else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" role="img" aria-label="{title}">'
            f'<title>{title}</title>{bgr}{frag}</svg>')


def inline(frag, w, h, width, label="CaSe Solutions"):
    height = width * h / w
    return closed(f'<svg viewBox="0 0 {w:.2f} {h:.2f}" width="{width:.0f}" height="{height:.1f}" '
                  f'role="img" aria-label="{label}" style="display: block">{frag}</svg>')


def app_icon(kind, size, bg, fg, caret=None, label="Ícono de app"):
    frag, W, H = mark_svg(kind, fg, caret)
    box = 100.0
    m = 0.56 * box                       # mark occupies 56% of the tile
    s = m / max(W, H)
    ox, oy = (box - W * s) / 2, (box - H * s) / 2
    if kind == "dos":                    # optical: the tall S reads small, give it more height
        s = 0.62 * box / H
        ox, oy = (box - W * s) / 2, (box - H * s) / 2
    inner = f'<g transform="translate({ox:.2f} {oy:.2f}) scale({s:.5f})">{frag}</g>'
    return closed(f'<svg viewBox="0 0 100 100" width="{size}" height="{size}" role="img" aria-label="{label}" '
                  f'style="display: block"><rect width="100" height="100" rx="22.5" fill="{bg}"></rect>{inner}</svg>')


def favicon(kind, px, fg, caret=None):
    frag, W, H = mark_svg(kind, fg, caret, small=px <= 24)
    s = px / max(W, H)
    ox, oy = (px - W * s) / 2, (px - H * s) / 2
    return closed(f'<svg viewBox="0 0 {px} {px}" width="{px}" height="{px}" role="img" aria-label="Favicon {px} px" '
                  f'style="display: block"><g transform="translate({ox:.3f} {oy:.3f}) scale({s:.5f})">{frag}</g></svg>')


# ---------------------------------------------------------------- logo files
for kind, meta in DIRS.items():
    caret = BLUE if kind == "cursor" else None
    for tone, fg in (("negro", INK), ("blanco", PAPER)):
        frag, w, h = lockup_svg(kind, fg, caret)
        open(f"{OUT}/{meta['slug']}_logo_{tone}.svg", "w").write(standalone(frag, w, h))
        frag, w, h = lockup_svg(kind, fg, caret, compact=True)
        open(f"{OUT}/{meta['slug']}_corto_{tone}.svg", "w").write(standalone(frag, w, h))
        frag, W, H = mark_svg(kind, fg, caret)
        open(f"{OUT}/{meta['slug']}_simbolo_{tone}.svg", "w").write(standalone(frag, W, H))

# ---------------------------------------------------------------- artboards
HEAD = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<style>
body{{margin:0}}
a{{color:#555}}a:hover{{color:#111}}
</style>
</helmet>
"""
TAIL = """</x-dc>
<script type="text/x-dc" data-dc-script data-props='{props}'>
class Component extends DCLogic {{
renderVals() {{
return {{ {vals} }};
}}
}}
</script>
</body>
</html>
"""
W_AB, H_AB = 1200, 675


def board(title, body, props=None, vals=""):
    p = {"$preview": {"width": W_AB, "height": H_AB}}
    if props:
        p.update(props)
    return HEAD.format(title=title) + body + TAIL.format(props=json.dumps(p, ensure_ascii=False), vals=vals)


def caret_props(default, opts):
    return {"caret": {"editor": "color", "default": default, "options": opts, "section": "Marca"}}


files = {}
boards = {}
order = []
notes = {}
ROW_GAP = 1100
for r, (kind, meta) in enumerate(DIRS.items()):
    y0 = r * ROW_GAP
    slug = meta["slug"]
    is_cur = kind == "cursor"
    hole = "{{caret}}"
    # Principal (light)
    frag, w, h = lockup_svg(kind, INK, hole if is_cur else None)
    body = (f'<div style="width: {W_AB}px; height: {H_AB}px; background: {PAPER}; display: flex; '
            f'align-items: center; justify-content: center">\n{inline(frag, w, h, 640)}\n</div>\n')
    name = "Main.dc.html" if r == 0 else f"{slug}-principal.dc.html"
    files[name] = board(f"{meta['name']}: logo principal", body,
                        caret_props(BLUE, [BLUE, INK, "#FF5A1F"]) if is_cur else None,
                        f"caret: this.props.caret ?? '{BLUE}'" if is_cur else "")
    boards[name] = {"x": 0, "y": y0, "w": W_AB, "h": H_AB, "title": f"{meta['name']} · principal"}
    order.append(name)
    # Inverso (dark)
    frag, w, h = lockup_svg(kind, PAPER, hole if is_cur else None)
    body = (f'<div style="width: {W_AB}px; height: {H_AB}px; background: {INK}; display: flex; '
            f'align-items: center; justify-content: center">\n{inline(frag, w, h, 640)}\n</div>\n')
    name = f"{slug}-inverso.dc.html"
    files[name] = board(f"{meta['name']}: logo inverso", body,
                        caret_props(BLUE, [BLUE, PAPER, "#FF5A1F"]) if is_cur else None,
                        f"caret: this.props.caret ?? '{BLUE}'" if is_cur else "")
    boards[name] = {"x": W_AB + 80, "y": y0, "w": W_AB, "h": H_AB, "title": f"{meta['name']} · inverso"}
    order.append(name)
    # Aplicaciones
    c = hole if is_cur else None
    icon_dark = app_icon(kind, 196, INK, PAPER, c, "Ícono de app, fondo negro")
    icon_light = app_icon(kind, 196, PAPER, INK, c, "Ícono de app, fondo blanco")
    fav32 = favicon(kind, 32, INK, c)
    sizes = "".join(
        f'<div style="display: flex; flex-direction: column; align-items: center; justify-content: flex-end; gap: 14px; height: 104px">'
        f'{favicon(kind, px, INK, c)}<span style="font: 500 13px/1 system-ui, sans-serif; color: #6A6A6A">{px} px</span></div>'
        for px in (64, 32, 24, 16))
    cfrag, cw, ch = lockup_svg(kind, INK, c, compact=True)
    close_icon = ('<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" style="display: block">'
                  '<path d="M7 7l10 10M17 7L7 17" stroke="#6A6A6A" stroke-width="2" fill="none" stroke-linecap="round"></path></svg>')
    body = f"""<div style="width: {W_AB}px; height: {H_AB}px; background: {GREY}; box-sizing: border-box; padding: 72px 80px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); column-gap: 64px; align-items: center">
<div style="display: flex; gap: 28px; align-items: center; justify-content: center">
<div style="border-radius: 44px; box-shadow: 0 18px 40px rgba(0,0,0,0.16)">{icon_dark}</div>
<div style="border-radius: 44px; box-shadow: 0 18px 40px rgba(0,0,0,0.10)">{icon_light}</div>
</div>
<div style="display: flex; flex-direction: column; gap: 56px">
<div style="background: #DADADA; border-radius: 18px 18px 0 0; padding: 14px 14px 0 14px">
<div style="background: {PAPER}; border-radius: 16px 16px 0 0; height: 64px; display: flex; align-items: center; gap: 16px; padding: 0 20px; width: 400px">
{fav32}
<span style="font: 500 24px/1 system-ui, sans-serif; color: #1A1A1A; flex-grow: 1; white-space: nowrap">CaSe Solutions</span>
{close_icon}
</div>
</div>
<div style="display: flex; gap: 36px; align-items: flex-end">{sizes}</div>
<div>{inline(cfrag, cw, ch, 220, "CaSe")}</div>
</div>
</div>
"""
    name = f"{slug}-aplicaciones.dc.html"
    files[name] = board(f"{meta['name']}: aplicaciones", body,
                        caret_props(BLUE, [BLUE, INK, "#FF5A1F"]) if is_cur else None,
                        f"caret: this.props.caret ?? '{BLUE}'" if is_cur else "")
    boards[name] = {"x": 2 * (W_AB + 80), "y": y0, "w": W_AB, "h": H_AB, "title": f"{meta['name']} · aplicaciones"}
    order.append(name)
    notes[f"t{r}"] = {"x": 0, "y": y0 - 300, "text": meta["name"], "kind": "title1", "maxW": 3 * W_AB + 160}

notes["s0"] = {"x": 3 * (W_AB + 80), "y": 0, "w": 380, "size": "l",
               "text": "Dos piezas iguales con forma de C; giradas, forman la S. Las dos letras de CaSe en un solo símbolo, y dos socios en una sola marca. Bajo 24 px se usa sin la ranura."}
notes["s1"] = {"x": 3 * (W_AB + 80), "y": ROW_GAP, "w": 380, "size": "l",
               "text": "La C de CaSe sostiene el cursor de texto: el momento en que una web empieza a escribirse. El cursor es el único color de la marca y puede parpadear en la web."}
notes["s2"] = {"x": 3 * (W_AB + 80), "y": 2 * ROW_GAP, "w": 380, "size": "l",
               "text": "Un bloque sólido cortado por la barra de una URL. Dos partes que encajan en un solo cuadrado: la más fuerte en tamaños pequeños."}

canvas = {
    "v": 3,
    "createdOnFiles": {"v": 1, "at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")},
    "title": "CaSe Solutions · Logo",
    "launch": {"view": "canvas"},
    "pages": [],
    "boards": boards,
    "order": order,
    "notes": notes,
    "designSystems": [],
}
open(os.path.join(PROJ, "canvas.json"), "w").write(json.dumps(canvas, ensure_ascii=False, indent=1))
for n, src in files.items():
    open(os.path.join(PROJ, n), "w").write(src)
print("\n".join(f"{n} {len(s)//1024} KB" for n, s in files.items()))
