"""Real-size audit: lockups at header sizes, marks at favicon sizes, light and dark."""
import sys
sys.path.insert(0, "/home/claude/case/tools")
from lockup import lockup, mark_only

DIRS = [("dos", "mona-sans"), ("cursor", "instrument-sans"), ("ruta", "schibsted-grotesk")]
INK, PAPER = "#0A0A0A", "#FFFFFF"
rows = []
y = 20
for i, (k, fam) in enumerate(DIRS):
    for j, (bg, fg) in enumerate([(PAPER, INK), (INK, PAPER)]):
        rows.append(f'<rect x="0" y="{y-10}" width="900" height="70" fill="{bg}"/>')
        x = 20
        for cap in (9, 12, 16):
            frag, lw, lh = lockup(k, fam, 600, text="CaSe", text2="Solutions", weight2=400, fill=fg,
                                  cap_px=cap, gap_ratio=0.5, x=x, y=y + (40 - cap * 1.42) / 2, uid=f"a{i}{j}{cap}")
            rows.append(frag)
            x += lw + 30
        for sz in (16, 24, 32, 48):
            rows.append(mark_only(k, sz, fill=fg, x=x, y=y + (40 - sz) / 2, uid=f"b{i}{j}{sz}"))
            x += sz + 16
        if k == "dos":
            for sz in (16, 24, 32):
                rows.append(mark_only("dos_solid", sz, fill=fg, x=x, y=y + (40 - sz) / 2, uid=f"c{i}{j}{sz}"))
                x += sz + 16
        y += 70
svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="900" height="{y}"><rect width="100%" height="100%" fill="#ccc"/>{"".join(rows)}</svg>'
open("/home/claude/case/out/sheet3.svg", "w").write(svg)
