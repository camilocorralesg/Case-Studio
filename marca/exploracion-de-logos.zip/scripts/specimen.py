import sys
sys.path.insert(0, "/home/claude/case/tools")
from textpath import font_file, text_path

fams = ["instrument-sans", "host-grotesk", "familjen-grotesk", "schibsted-grotesk", "onest", "mona-sans"]
rows = []
y = 90
for fam in fams:
    for w in (500, 600):
        try:
            f = font_file(fam, w)
        except FileNotFoundError:
            continue
        d, wd, _ = text_path(f, "CaSe Solutions", 64, 40, y, tracking=-0.03)
        d2, _, _ = text_path(f, "case", 64, 620, y, tracking=-0.03)
        lab, _, _ = text_path(font_file("onest", 400), f"{fam} {w}", 14, 940, y - 4)
        rows.append(f'<path d="{d}"/><path d="{d2}"/><path fill="#888" d="{lab}"/>')
        y += 92
svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="1140" height="{y}" viewBox="0 0 1140 {y}"><rect width="100%" height="100%" fill="#fff"/><g fill="#000">{"".join(rows)}</g></svg>'
open("/home/claude/case/out/specimen.svg", "w").write(svg)
