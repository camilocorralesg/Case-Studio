import sys
sys.path.insert(0, "/home/claude/case/tools")
import marks as M

INK, PAPER = "#0A0A0A", "#FFFFFF"


def place(d, w, h, x, y, size, fill):
    s = size / max(w, h)
    ox = x + (size - w * s) / 2
    oy = y + (size - h * s) / 2
    return f'<path transform="translate({ox:.2f} {oy:.2f}) scale({s:.4f})" fill="{fill}" d="{d}"/>'


def place_ruta(x, y, size, fill, uid, **kw):
    s = size / 100
    return f'<g transform="translate({x} {y}) scale({s:.4f})">{M.ruta_svg(fill, uid=uid, **kw)}</g>'


items = [
    ("dos_piezas", M.dos_piezas()),
    ("dos_piezas_sin_corte", M.dos_piezas(gap=0)),
    ("escalon", M.escalon()),
    ("cursor_dentro", M.cursor()),
    ("cursor_fuera", M.cursor(inside=False)),
    ("marco", M.marco()),
]
rows = []
y = 20
for i, (name, (d, w, h)) in enumerate(items):
    rows.append(f'<rect x="20" y="{y}" width="220" height="220" fill="{PAPER}" stroke="#ddd"/>')
    rows.append(place(d, w, h, 50, y + 30, 160, INK))
    rows.append(f'<rect x="250" y="{y}" width="220" height="220" fill="{INK}"/>')
    rows.append(place(d, w, h, 280, y + 30, 160, PAPER))
    rows.append(place(d, w, h, 490, y + 20, 64, INK))
    rows.append(place(d, w, h, 570, y + 20, 32, INK))
    rows.append(place(d, w, h, 610, y + 20, 16, INK))
    rows.append(f'<text x="490" y="{y+130}" font-family="sans-serif" font-size="14" fill="#666">{name}</text>')
    y += 240
# ruta variants
for j, kw in enumerate([dict(), dict(shift=6), dict(angle=58, w=13, shift=0, r=28)]):
    rows.append(f'<rect x="20" y="{y}" width="220" height="220" fill="{PAPER}" stroke="#ddd"/>')
    rows.append(place_ruta(50, y + 30, 160, INK, f"a{j}", **kw))
    rows.append(f'<rect x="250" y="{y}" width="220" height="220" fill="{INK}"/>')
    rows.append(place_ruta(280, y + 30, 160, PAPER, f"b{j}", **kw))
    rows.append(place_ruta(490, y + 20, 64, INK, f"c{j}", **kw))
    rows.append(place_ruta(570, y + 20, 32, INK, f"d{j}", **kw))
    rows.append(place_ruta(610, y + 20, 16, INK, f"e{j}", **kw))
    rows.append(f'<text x="490" y="{y+130}" font-family="sans-serif" font-size="14" fill="#666">ruta {kw}</text>')
    y += 240
svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="700" height="{y}"><rect width="100%" height="100%" fill="#f4f4f4"/>{"".join(rows)}</svg>'
open("/home/claude/case/out/sheet1.svg", "w").write(svg)
