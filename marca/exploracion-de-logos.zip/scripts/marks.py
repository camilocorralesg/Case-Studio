"""Mark geometry for the CaSe Solutions logo directions. All marks live in a 0..100 box
(width may differ); each function returns (d, width, height)."""
import math


def f(v):
    return f"{v:.3f}".rstrip("0").rstrip(".")


def arc_piece(cx, cy, R, t, L, rot=False, ox=0.0, oy=0.0, W=0, H=0):
    """Top 'C' piece: stub from (cx+L, cy-R) to (cx, cy-R), then the left semicircle
    down to (cx, cy+R); butt ends. rot=True rotates 180deg inside a W x H box."""
    ro, ri = R + t / 2, R - t / 2
    pts = [
        ("M", cx + L, cy - ro),
        ("L", cx, cy - ro),
        ("A", ro, 0, cx, cy + ro),   # outer, top -> left -> bottom (ccw on screen)
        ("L", cx, cy + ri),
        ("A", ri, 1, cx, cy - ri),   # inner, bottom -> left -> top
        ("L", cx + L, cy - ri),
    ]

    def tr(x, y):
        x, y = x + ox, y + oy
        if rot:
            x, y = W - x, H - y
        return x, y

    out = []
    for p in pts:
        if p[0] in "ML":
            x, y = tr(p[1], p[2])
            out.append(f"{p[0]}{f(x)} {f(y)}")
        else:
            _, r, sweep, x, y = p
            x, y = tr(x, y)
            out.append(f"A{f(r)} {f(r)} 0 0 {sweep} {f(x)} {f(y)}")
    return "".join(out) + "Z"


def dos_piezas(t=17.0, gap=5.0, stub=None):
    """S built from two identical C-shaped pieces, rotated 180deg, split by a slit."""
    R = 21.0
    W = 2 * R + t + gap
    H = 4 * R + t
    L = stub if stub is not None else R * 0.95
    cx = t / 2 + R
    cy = t / 2 + R
    a = arc_piece(cx, cy, R, t, L, rot=False, ox=0, oy=0)
    b = arc_piece(cx, cy, R, t, L, rot=True, ox=0, oy=0, W=W, H=H)
    return a + b, W, H


def ruta(r=24.0, w=11.0, angle=64.0, shift=0.0):
    """Rounded square split by a URL slash; pieces optionally slid along the cut."""
    S = 100.0
    # slash line through centre at `angle` degrees from horizontal (like '/').
    th = math.radians(angle)
    dx, dy = math.cos(th), -math.sin(th)          # direction of the slash (up-right)
    nx, ny = -dy, dx                               # normal (pointing down-right? check)
    # Build with a clipPath: we return a composite description instead.
    return {"S": S, "r": r, "w": w, "angle": angle, "shift": shift}


def ruta_svg(fill, r=24.0, w=11.0, angle=64.0, shift=0.0, uid="r"):
    """Return SVG fragment (defs + shapes) for the Ruta mark in a 100x100 box."""
    S = 100.0
    th = math.radians(angle)
    ux, uy = math.cos(th), -math.sin(th)     # along slash (up-right)
    nx, ny = math.sin(th), math.cos(th)      # normal, pointing to lower-right
    c = 50.0
    big = 200.0
    h = w / 2

    def half(sign):
        # polygon of the half-plane on side `sign` of the slash, offset by the gap
        o = sign * h
        p1 = (c + nx * o - ux * big, c + ny * o - uy * big)
        p2 = (c + nx * o + ux * big, c + ny * o + uy * big)
        p3 = (p2[0] + nx * sign * big, p2[1] + ny * sign * big)
        p4 = (p1[0] + nx * sign * big, p1[1] + ny * sign * big)
        return " ".join(f"{f(x)},{f(y)}" for x, y in (p1, p2, p3, p4))

    sx, sy = ux * shift, uy * shift
    return (
        f'<defs><clipPath id="{uid}a"><polygon points="{half(-1)}"/></clipPath>'
        f'<clipPath id="{uid}b"><polygon points="{half(1)}"/></clipPath></defs>'
        f'<g transform="translate({f(-sx)} {f(-sy)})"><rect clip-path="url(#{uid}a)" width="{S}" height="{S}" rx="{r}" fill="{fill}"/></g>'
        f'<g transform="translate({f(sx)} {f(sy)})"><rect clip-path="url(#{uid}b)" width="{S}" height="{S}" rx="{r}" fill="{fill}"/></g>'
    )


def cursor(t=19.0, open_deg=46.0, caret_w=11.5, inside=True, ext=0.0, split=False):
    """Geometric C (ring opening to the right) holding a text caret.
    ext: caret overshoot above and below the C. split=True returns (ring, caret, W, H)."""
    Ro = 50.0
    Ri = Ro - t
    a = math.radians(open_deg)
    cx, cy = 50.0, 50.0 + ext
    o1 = (cx + Ro * math.cos(a), cy - Ro * math.sin(a))
    o2 = (cx + Ro * math.cos(a), cy + Ro * math.sin(a))
    i1 = (cx + Ri * math.cos(a), cy - Ri * math.sin(a))
    i2 = (cx + Ri * math.cos(a), cy + Ri * math.sin(a))
    ring = (f"M{f(o1[0])} {f(o1[1])}A{f(Ro)} {f(Ro)} 0 1 0 {f(o2[0])} {f(o2[1])}"
            f"L{f(i2[0])} {f(i2[1])}A{f(Ri)} {f(Ri)} 0 1 1 {f(i1[0])} {f(i1[1])}Z")
    if inside:
        x = cx + Ri + (Ro - Ri - caret_w) / 2 + 3
        W = 100.0
    else:
        x = 100 + 10
        W = x + caret_w
    H = 100.0 + 2 * ext
    caret = f"M{f(x)} 0h{f(caret_w)}v{f(H)}h{f(-caret_w)}Z"
    if split:
        return ring, caret, W, H
    return ring + caret, W, H


def marco(t=19.0, arm=58.0, r=0.0):
    """Two corner brackets (top-left, bottom-right) framing an empty square."""
    S = 100.0
    a = (f"M0 0H{f(arm)}V{f(t)}H{f(t)}V{f(arm)}H0Z")
    b = (f"M{f(S)} {f(S)}H{f(S-arm)}V{f(S-t)}H{f(S-t)}V{f(S-arm)}H{f(S)}Z")
    return a + b, S, S


def escalon(t=19.0, gap=6.0):
    """Squared S from two identical bracket pieces (angular sibling of dos_piezas)."""
    W = 64.0
    H = 100.0
    m = H / 2
    # top piece: top bar + left post + middle bar (a squared C), ends before the gap
    a = (f"M{f(W)} 0V{f(t)}H{f(t)}V{f(m - t/2)}H{f(W/2 - gap/2)}V{f(m + t/2)}H0V0Z")
    b = (f"M0 {f(H)}V{f(H - t)}H{f(W - t)}V{f(m + t/2)}H{f(W/2 + gap/2)}V{f(m - t/2)}H{f(W)}V{f(H)}Z")
    return a + b, W, H


def ruta_path(r=None, w=11.0, angle=67.0):
    """Rounded square split by a URL slash, as two exact paths (no clipping).
    Geometry is chosen so both cut lines land on the straight top/bottom edges."""
    th = math.radians(angle)
    run = 50 / math.tan(th)
    off = (w / 2) / math.sin(th)
    xa, xb = 50 + run - off, 50 - run - off          # left piece cut: top, bottom
    if r is None:
        r = xb      # corners end exactly where the cuts land: no slivers
    assert r <= xb + 1e-9 and xa + 2 * off <= 100 - r + 1e-9, "cut must land on straight edges"
    S = 100.0
    left = (f"M{f(xa)} 0H{f(r)}A{f(r)} {f(r)} 0 0 0 0 {f(r)}V{f(S - r)}"
            f"A{f(r)} {f(r)} 0 0 0 {f(r)} {f(S)}H{f(xb)}Z")
    right = (f"M{f(S - xa)} {f(S)}H{f(S - r)}A{f(r)} {f(r)} 0 0 0 {f(S)} {f(S - r)}V{f(r)}"
             f"A{f(r)} {f(r)} 0 0 0 {f(S - r)} 0H{f(S - xb)}Z")
    return left + right, S, S
