"""Render the finalists' type and colour grids as plain SVG sheets for a visual check."""
import sys
sys.path.insert(0, "/home/claude/case/tools")
import final as F

OUT = "/home/claude/case/out"


def sheet(kind):
    parts = []
    # type grid: 2 x 3
    for i, (fam, label, w1, w2) in enumerate(F.FONTS[kind]):
        frag, lw, lh = F.lockup(kind, fam, w1, w2, F.SHARED[0])
        k = F.CAP_TYPE[kind] / 100
        x = 60 + (i % 2) * 720
        y = 60 + (i // 2) * 170
        parts.append(f'<g transform="translate({x} {y}) scale({k:.4f})">{frag}</g>')
        parts.append(f'<text x="{x}" y="{y + lh * k + 30}" font-family="sans-serif" font-size="15" fill="#666">{label}</text>')
    # colour grid: 3 x 3
    fam, label, w1, w2 = F.FONTS[kind][F.CHOSEN[kind]]
    pals = F.SHARED + [F.SPECIAL[kind]]
    y0 = 600
    for i, pal in enumerate(pals):
        x = 40 + (i % 3) * 500
        y = y0 + (i // 3) * 290
        parts.append(f'<rect x="{x}" y="{y}" width="472" height="236" rx="14" fill="{pal["bg"]}" stroke="#DDD"/>')
        frag, lw, lh = F.lockup(kind, fam, w1, w2, pal)
        k = F.CAP_COLOR[kind] / 100
        ox = x + (472 - lw * k) / 2
        oy = y + (236 - lh * k) / 2
        parts.append(f'<g transform="translate({ox:.1f} {oy:.1f}) scale({k:.4f})">{frag}</g>')
        parts.append(f'<text x="{x}" y="{y + 258}" font-family="sans-serif" font-size="14" fill="#555">{pal["name"]}</text>')
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="1560" height="{y0 + 3 * 290 + 20}">'
           f'<rect width="100%" height="100%" fill="#F3F3F3"/><rect width="1560" height="580" fill="#FFF"/>{"".join(parts)}</svg>')
    open(f"{OUT}/fin_{kind}.svg", "w").write(svg)


for kind in ("formula", "cristal", "braille", "morse"):
    sheet(kind)
