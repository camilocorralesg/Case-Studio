"""CaSe Studio concepts. Each returns (layers, W, H); roles as in new.py."""
import math
import sys
sys.path.insert(0, "/home/claude/case/tools")
from marks import f
from new import rrect, rect
from new2 import circle, poly


# ------------------------------------------------------------ 1. Escuadra (set square)
def escuadra(hole=15.5, r=5.0):
    """A drafting set square: right angle at the bottom right, so the long edge rises like the
    slash of a web address. The round hole sits on the triangle's incentre."""
    # rounded-corner right triangle, drawn clockwise; hole drawn counter-clockwise
    A, B, C = (100.0, 0.0), (100.0, 100.0), (0.0, 100.0)
    pts = _round_poly([A, B, C], [r * 0.6, r, r * 0.6])
    inr = (100 + 100 - 100 * math.sqrt(2)) / 2
    cx, cy = 100 - inr, 100 - inr
    return [("fg", pts + circle(cx, cy, hole, ccw=True))], 100.0, 100.0


def _round_poly(P, radii, seg=10):
    """Polygon with rounded corners (arcs approximated), as a path string."""
    out = []
    n = len(P)
    for i in range(n):
        p0, p1, p2 = P[i - 1], P[i], P[(i + 1) % n]
        r = radii[i]
        v1 = (p0[0] - p1[0], p0[1] - p1[1]); l1 = math.hypot(*v1); v1 = (v1[0] / l1, v1[1] / l1)
        v2 = (p2[0] - p1[0], p2[1] - p1[1]); l2 = math.hypot(*v2); v2 = (v2[0] / l2, v2[1] / l2)
        ang = math.acos(max(-1, min(1, v1[0] * v2[0] + v1[1] * v2[1])))
        t = r / math.tan(ang / 2)
        a = (p1[0] + v1[0] * t, p1[1] + v1[1] * t)
        b = (p1[0] + v2[0] * t, p1[1] + v2[1] * t)
        for k in range(seg + 1):          # quadratic-ish blend between a, corner, b
            u = k / seg
            x = (1 - u) ** 2 * a[0] + 2 * (1 - u) * u * p1[0] + u * u * b[0]
            y = (1 - u) ** 2 * a[1] + 2 * (1 - u) * u * p1[1] + u * u * b[1]
            out.append((x, y))
    return poly(out)


# ------------------------------------------------------------ 2. Retícula (C on a dot grid)
def reticula(t=13.0, rc=22.0, dot=4.6):
    """A C drawn by snapping to a 4x4 layout grid; the grid points it does not use stay visible."""
    g = [8.0, 36.0, 64.0, 92.0]
    h = t / 2
    x0, y0, x1, y1 = g[0], g[0], g[3], g[3]
    c = (f"M{f(x1)} {f(y0 - h)}H{f(x0 + rc)}A{f(rc + h)} {f(rc + h)} 0 0 0 {f(x0 - h)} {f(y0 + rc)}"
         f"V{f(y1 - rc)}A{f(rc + h)} {f(rc + h)} 0 0 0 {f(x0 + rc)} {f(y1 + h)}H{f(x1)}"
         f"A{f(h)} {f(h)} 0 0 0 {f(x1)} {f(y1 - h)}H{f(x0 + rc)}"
         f"A{f(rc - h)} {f(rc - h)} 0 0 1 {f(x0 + h)} {f(y1 - rc)}V{f(y0 + rc)}"
         f"A{f(rc - h)} {f(rc - h)} 0 0 1 {f(x0 + rc)} {f(y0 + h)}H{f(x1)}"
         f"A{f(h)} {f(h)} 0 0 0 {f(x1)} {f(y0 - h)}Z")
    dots = "".join(circle(x, y, dot) for x in g[1:] for y in g[1:3])
    return [("fg", c), ("accent", dots)], 100.0, 100.0


def reticula_small():
    layers, W, H = reticula(t=16.0)
    return layers[:1], W, H


# ------------------------------------------------------------ 3. Ion (Ca2+ gives, Se2- takes)
def ion(rs=20.0, rb=37.0, ring=8.0, gap=9.0, e=6.6):
    """Calcium gives two electrons and selenium takes them: an ionic bond. Calcium is the small
    solid ion; selenide the large ring (about twice the size in the crystal), with the two
    electrons it just received sitting on its edge, facing calcium."""
    H = 2 * rb
    cy = rb
    cxs = rs
    cxb = 2 * rs + gap + rb
    W = cxb + rb
    ringd = circle(cxb, cy, rb) + circle(cxb, cy, rb - ring, ccw=True)
    rr = rb - ring / 2
    el = "".join(circle(cxb + rr * math.cos(math.radians(a)), cy + rr * math.sin(math.radians(a)), e)
                 for a in (152, 208))
    return [("fg", circle(cxs, cy, rs)), ("fg", ringd), ("accent", el)], W, H


# ------------------------------------------------------------ 4. Lienzo (artboard + label)
def lienzo(t=9.0, r=12.0, label_w=44.0, label_h=11.0, gap=7.0):
    """A design-tool artboard with its name above it: where every project starts."""
    top = label_h + gap
    S = 100.0
    frame = rrect(0, top, S, S - top, r) + rrect(t, top + t, S - 2 * t, S - top - 2 * t, max(r - t, 2), ccw=True)
    label = rrect(0, 0, label_w, label_h, label_h / 2)
    return [("fg", frame), ("accent", label)], S, S


# ------------------------------------------------------------ 5. Pliegue (folded ribbon S)
def pliegue(h=22.0, gap=17.0):
    """One paper ribbon folded twice makes the S: the front in ink, the back in the accent."""
    W = 100.0
    y_top, y_mid, y_bot = 0.0, h + gap, 2 * (h + gap)
    front, back = [], []
    # top run (front) from the left corner diagonal to the right edge
    front.append(poly([(0, y_top), (W, y_top), (W, y_top + h), (h, y_top + h)]))
    # left fold: lower-left triangle of the top-left corner + vertical + upper-left of mid corner
    back.append(poly([(0, y_top), (h, y_top + h), (h, y_mid), (0, y_mid + h)]))
    # middle run (front): from the left corner diagonal to the right corner diagonal
    front.append(poly([(h, y_mid), (W, y_mid), (W - h, y_mid + h), (0, y_mid + h)]))
    # right fold: lower-right of mid-right corner + vertical + upper-right of bottom-right corner
    back.append(poly([(W, y_mid), (W, y_bot + h), (W - h, y_bot), (W - h, y_mid + h)]))
    # bottom run (front)
    front.append(poly([(0, y_bot), (W - h, y_bot), (W, y_bot + h), (0, y_bot + h)]))
    return [("fg", "".join(front)), ("accent", "".join(back))], W, y_bot + h


CONCEPTS3 = [
    ("escuadra", "Escuadra", escuadra, "suse"),
    ("reticula", "Retícula", reticula, "chivo"),
    ("ion", "Ion", ion, "red-hat-display"),
    ("lienzo", "Lienzo", lienzo, "albert-sans"),
    ("pliegue", "Pliegue", pliegue, "instrument-serif"),
]
