"""Compose logo lockups (mark + outlined wordmark) as SVG fragments."""
import sys
sys.path.insert(0, "/home/claude/case/tools")
import marks as M
from textpath import font_file, text_path, metrics


def mark_frag(kind, fill, accent=None, uid="m"):
    """Return (svg_fragment_in_mark_units, W, H)."""
    if kind == "dos":
        d, W, H = M.dos_piezas()
        return f'<path fill="{fill}" d="{d}"/>', W, H
    if kind == "dos_solid":
        d, W, H = M.dos_piezas(gap=0)
        return f'<path fill="{fill}" d="{d}"/>', W, H
    if kind == "cursor":
        ring, caret, W, H = M.cursor(ext=7, split=True)
        return (f'<path fill="{fill}" d="{ring}"/><path fill="{accent or fill}" d="{caret}"/>', W, H)
    if kind == "ruta":
        d, W, H = M.ruta_path()
        return f'<path fill="{fill}" d="{d}"/>', W, H
    raise ValueError(kind)


def lockup(kind, family, weight, text="CaSe Solutions", fill="#0A0A0A", accent=None,
           cap_px=40.0, mark_ratio=1.42, gap_ratio=0.5, tracking=-0.025, uid="m",
           text2=None, weight2=None, fill2=None, x=0.0, y=0.0, extra=None):
    """Horizontal lockup. Returns (svg_fragment, width, height)."""
    fpath = font_file(family, weight)
    mt = metrics(fpath)
    size = cap_px / mt["cap"]
    frag, W, H = mark_frag(kind, fill, accent, uid)
    mh = cap_px * mark_ratio
    s = mh / H
    mw = W * s
    gap = mh * (gap_ratio * 0.86 if kind == "ruta" else gap_ratio)
    # caps centred on the mark: baseline at mark middle + cap/2
    base = y + mh / 2 + cap_px / 2
    tx = x + mw + gap
    d, tw, bb = text_path(fpath, text, size, tx, base, tracking=tracking, extra=extra)
    parts = [f'<g transform="translate({x:.2f} {y:.2f}) scale({s:.5f})">{frag}</g>',
             f'<path fill="{fill}" d="{d}"/>']
    total = tx + tw
    if text2:
        f2 = font_file(family, weight2 or weight)
        sp = size * 0.26
        d2, tw2, _ = text_path(f2, text2, size, total + sp, base, tracking=tracking)
        parts.append(f'<path fill="{fill2 or fill}" d="{d2}"/>')
        total = total + sp + tw2
    return "".join(parts), total - x, mh


def mark_only(kind, size, fill="#0A0A0A", accent=None, x=0.0, y=0.0, uid="m"):
    frag, W, H = mark_frag(kind, fill, accent, uid)
    s = size / max(W, H)
    ox = x + (size - W * s) / 2
    oy = y + (size - H * s) / 2
    return f'<g transform="translate({ox:.2f} {oy:.2f}) scale({s:.5f})">{frag}</g>'
