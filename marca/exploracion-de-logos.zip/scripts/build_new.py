"""Five new concepts: logo files and a 'Nuevos diseños' canvas page (principal, inverso, aplicaciones)."""
import json
import os
import sys

sys.path.insert(0, "/home/claude/case/tools")
import v2
import new
import new2
import new3
import new4
from textpath import font_file, text_path, metrics

INK, PAPER, BLUE, GREY = "#0A0A0A", "#FFFFFF", "#3355FF", "#EFEFEF"
PROJ = "/home/claude/case/canvas/project"
W_AB, H_AB = 1200, 675
REG = {c[0]: c[2] for c in new.CONCEPTS + new2.CONCEPTS2 + new3.CONCEPTS3 + new4.CONCEPTS4}
NAME = {"word2": "Solutions"}
WEIGHTS = {"pliegue": (400, (400, "italic")), "hex": (500, 400), "braille": (700, 400)}
WORD1 = {"hex": "#CA5E"}
SMALL = {"formula": new.formula_small, "bezier": new2.bezier_small, "reticula": new3.reticula_small,
         "css": new4.css_small, "morse": new4.morse_small, "braille": new4.braille_small}


def closed(svg):
    return svg.replace('"/>', '"></path>')


def g(layers, fg, accent, s=1.0, ox=0.0, oy=0.0):
    return f'<g transform="translate({ox:.2f} {oy:.2f}) scale({s:.5f})">{v2.frag(layers, fg, accent)}</g>'


def lockup(cid, fam, fg, accent, compact=False, cap=100.0):
    if cid == "css":
        runs = [("C", "h"), ("a", "l"), ("S", "h"), ("e", "l")]
        if not compact:
            runs += [(" ", "l"), (NAME["word2"][0], "h"), (NAME["word2"][1:], "l")]
        paths, w = new4.css_runs(runs, cap, 0, cap * 1.08)
        return "".join(f'<path fill="{fg}" d="{p}"/>' for p in paths), w, cap * 1.08
    layers, W, H = REG[cid]()
    w1, w2_ = WEIGHTS.get(cid, (600, 400))
    f6, f4 = font_file(fam, w1), font_file(fam, w2_)
    size = cap / metrics(f6)["cap"]
    if cid == "formula":
        # tiles spell CaSe: the word "Solutions" sits on the tiles' baseline at their cap height
        mh = cap / 0.40
        s = mh / H
        if compact:
            return g(layers, fg, accent, s), W * s, mh
        gap = 0.16 * mh
        base = 0.83 * mh
        d, w, _ = text_path(font_file(fam, 500), NAME["word2"], size, W * s + gap, base, tracking=-0.02)
        return g(layers, fg, accent, s) + f'<path fill="{fg}" d="{d}"/>', W * s + gap + w, mh
    mh = cap * {"bezier": 1.75, "switch": 1.2, "ion": 1.25, "pliegue": 1.12, "hex": 1.18, "braille": 1.0,
                "morse": 1.3, "mitades": 1.5}.get(cid, 1.42)
    s = mh / H
    mw = W * s
    gap = mh * {"bezier": 0.36, "switch": 0.36, "ion": 0.34, "hex": 0.36, "braille": 0.85, "morse": 0.42,
                "mitades": 0.42}.get(cid, 0.43 if W / H > 0.95 else 0.5)
    base = mh / 2 + cap / 2
    tr = -0.01 if cid == "hex" else -0.025
    d1, w1, _ = text_path(f6, WORD1.get(cid, "CaSe"), size, mw + gap, base, tracking=tr)
    out = g(layers, fg, accent, s) + f'<path fill="{fg}" d="{d1}"/>'
    total = mw + gap + w1
    if not compact:
        sp = size * 0.26
        d2, w2, _ = text_path(f4, NAME["word2"], size, total + sp, base,
                              tracking=0.0 if cid == "pliegue" else tr)
        out += f'<path fill="{fg}" d="{d2}"/>'
        total += sp + w2
    return out, total, mh


def svg_inline(frag, w, h, width, label=None):
    label = label or "CaSe " + NAME["word2"]
    return closed(f'<svg viewBox="0 0 {w:.2f} {h:.2f}" width="{width:.0f}" height="{width * h / w:.1f}" '
                  f'role="img" aria-label="{label}" style="display: block">{frag}</svg>')


def favicon_layers(cid):
    return SMALL.get(cid, REG[cid])()


def favicon(cid, px, fg, accent):
    layers, W, H = favicon_layers(cid)
    s = px / max(W, H)
    return closed(f'<svg viewBox="0 0 {px} {px}" width="{px}" height="{px}" role="img" aria-label="Favicon {px} px" '
                  f'style="display: block">{g(layers, fg, accent, s, (px - W * s) / 2, (px - H * s) / 2)}</svg>')


def app_icon(cid, size, bg, fg, accent, label):
    if cid == "hex":
        if bg == INK:   # dark tile holding the swatch
            inner = g([("hex", new.rrect(0, 0, 100, 100, 18))], fg, accent, 0.5, 25, 25)
            tile = INK
        else:           # the colour itself, with its value
            d, w, _ = text_path(font_file("dm-mono", 500), "#CA5E", 20, 0, 0)
            sc = 64 / w
            inner = f'<path fill="{INK}" transform="translate(18 {50 + 0.7 * 20 * sc / 2:.2f}) scale({sc:.4f})" d="{d}"/>'
            tile = "#CA5E"
        return closed(f'<svg viewBox="0 0 100 100" width="{size}" height="{size}" role="img" aria-label="{label}" '
                      f'style="display: block"><rect width="100" height="100" rx="22.5" fill="{tile}"></rect>{inner}</svg>')
    if cid == "formula":
        layers, W, H = new.formula_icon()
        inner = g(layers, fg, accent, 1.0, 4, 0)
    else:
        layers, W, H = REG[cid]()
        m = 0.56 if W / H <= 1.2 else 0.66
        s = m * 100 / max(W, H)
        inner = g(layers, fg, accent, s, (100 - W * s) / 2, (100 - H * s) / 2)
    return closed(f'<svg viewBox="0 0 100 100" width="{size}" height="{size}" role="img" aria-label="{label}" '
                  f'style="display: block"><rect width="100" height="100" rx="22.5" fill="{bg}"></rect>{inner}</svg>')


HEAD = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<style>
body{{margin:0}}
</style>
</helmet>
"""
TAIL = """</x-dc>
<script type="text/x-dc" data-dc-script data-props='{props}'>
class Component extends DCLogic {{
renderVals() {{
return {{ {vals} }};
}}
}}
</script>
</body>
</html>
"""


def board(title, body, accent):
    props = {"$preview": {"width": W_AB, "height": H_AB}}
    vals = ""
    if accent:
        props["accent"] = {"editor": "color", "default": BLUE, "options": [BLUE, "#FF5A1F", "#0E9F6E"], "section": "Marca"}
        vals = f"accent: this.props.accent ?? '{BLUE}'"
    return HEAD.format(title=title) + body + TAIL.format(props=json.dumps(props, ensure_ascii=False), vals=vals)


ROW = 1100
STICKY1 = {
    "formula": "Ca es calcio y Se es selenio: el seleniuro de calcio se escribe CaSe. Dos elementos, un compuesto. Las fichas ya dicen CaSe, así que el logo solo añade «Solutions».",
    "caja-alta": "En tipografía, mayúsculas y minúsculas son caja alta y caja baja. CaSe alterna las dos: cuadrados para C y S, círculos para a y e, sobre la misma línea base.",
    "marco": "El marco de selección de una herramienta de diseño, con el lado derecho abierto: forma una C. Habla de diseñar y construir.",
    "trazo": "Una sola línea dibuja la C y sigue hasta la S. Dos socios, un solo trazo.",
    "corchetes": "Case es estuche: unos corchetes de código que guardan un bloque. El bloque es el único color.",
}
def build(concepts, page_id, page_name, prefix, sticky, logos, word2="Solutions"):
    NAME["word2"] = word2
    os.makedirs(logos, exist_ok=True)
    files, boards, order, notes = {}, {}, [], {}
    for r, (cid, name, fn, fam) in enumerate(concepts):
        y0 = r * ROW
        layers, W, H = fn()
        has_acc = any(l[0] == "accent" for l in layers)
        acc = "{{accent}}" if has_acc else BLUE
        notes[f"{prefix}t{r}"] = {"x": 0, "y": y0 - 300, "text": name, "kind": "title1", "maxW": 3 * W_AB + 160, "page": page_id}
        notes[f"{prefix}s{r}"] = {"x": 3 * (W_AB + 80), "y": y0, "w": 380, "size": "l", "text": sticky[cid], "page": page_id}
        for tone, bgc, fgc in (("principal", PAPER, INK), ("inverso", INK, PAPER)):
            frag, w, h = lockup(cid, fam, fgc, acc)
            body = (f'<div style="width: {W_AB}px; height: {H_AB}px; background: {bgc}; display: flex; '
                    f'align-items: center; justify-content: center">\n{svg_inline(frag, w, h, 640)}\n</div>\n')
            nm = f"{prefix}-{cid}-{tone}.dc.html"
            files[nm] = board(f"{name}: logo {tone}", body, has_acc)
            boards[nm] = {"x": (0 if tone == "principal" else W_AB + 80), "y": y0, "w": W_AB, "h": H_AB,
                          "title": f"{name} · {tone}", "page": page_id}
            order.append(nm)
            # logo files
            fr, w2, h2 = lockup(cid, fam, fgc, BLUE)
            tag = "negro" if fgc == INK else "blanco"
            open(f"{logos}/{cid}_logo_{tag}.svg", "w").write(
                f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w2:.2f} {h2:.2f}"><title>CaSe {NAME["word2"]}</title>{fr}</svg>')
        # aplicaciones
        sizes = "".join(
            f'<div style="display: flex; flex-direction: column; align-items: center; justify-content: flex-end; gap: 14px; height: 104px">'
            f'{favicon(cid, px, INK, acc)}<span style="font: 500 13px/1 system-ui, sans-serif; color: #6A6A6A">{px} px</span></div>'
            for px in (64, 32, 24, 16))
        cfrag, cw, ch = lockup(cid, fam, INK, acc, compact=True)
        close_icon = ('<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" style="display: block">'
                      '<path d="M7 7l10 10M17 7L7 17" stroke="#6A6A6A" stroke-width="2" fill="none" stroke-linecap="round"></path></svg>')
        body = f"""<div style="width: {W_AB}px; height: {H_AB}px; background: {GREY}; box-sizing: border-box; padding: 72px 80px; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); column-gap: 64px; align-items: center">
    <div style="display: flex; gap: 28px; align-items: center; justify-content: center">
    <div style="border-radius: 44px; box-shadow: 0 18px 40px rgba(0,0,0,0.16)">{app_icon(cid, 196, INK, PAPER, acc, "Ícono de app, fondo negro")}</div>
    <div style="border-radius: 44px; box-shadow: 0 18px 40px rgba(0,0,0,0.10)">{app_icon(cid, 196, PAPER, INK, acc, "Ícono de app, fondo blanco")}</div>
    </div>
    <div style="display: flex; flex-direction: column; gap: 56px">
    <div style="background: #DADADA; border-radius: 18px 18px 0 0; padding: 14px 14px 0 14px">
    <div style="background: {PAPER}; border-radius: 16px 16px 0 0; height: 64px; display: flex; align-items: center; gap: 16px; padding: 0 20px; width: 400px">
    {favicon(cid, 32, INK, acc)}
    <span style="font: 500 24px/1 system-ui, sans-serif; color: #1A1A1A; flex-grow: 1; white-space: nowrap">CaSe {NAME["word2"]}</span>
    {close_icon}
    </div>
    </div>
    <div style="display: flex; gap: 36px; align-items: flex-end">{sizes}</div>
    <div>{svg_inline(cfrag, cw, ch, 220 if cw / ch > 2 else 120, "CaSe")}</div>
    </div>
    </div>
    """
        nm = f"{prefix}-{cid}-aplicaciones.dc.html"
        files[nm] = board(f"{name}: aplicaciones", body, has_acc)
        boards[nm] = {"x": 2 * (W_AB + 80), "y": y0, "w": W_AB, "h": H_AB, "title": f"{name} · aplicaciones", "page": page_id}
        order.append(nm)
        # mark file
        open(f"{logos}/{cid}_simbolo_negro.svg", "w").write(
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.2f} {H:.2f}"><title>CaSe {NAME["word2"]}</title>{v2.frag(layers, INK, BLUE)}</svg>')

    canvas = json.load(open(os.path.join(PROJ, "canvas.json")))
    pages = canvas.get("pages", [])
    if not any(p["id"] == page_id for p in pages):
        pages.append({"id": page_id, "name": page_name})
    canvas["pages"] = pages
    canvas["launch"] = {"view": "canvas", "page": page_id}
    canvas["boards"].update(boards)
    canvas["order"] += [n for n in order if n not in canvas["order"]]
    canvas["notes"].update(notes)
    open(os.path.join(PROJ, "canvas.json"), "w").write(json.dumps(canvas, ensure_ascii=False, indent=1))
    for n, src in files.items():
        open(os.path.join(PROJ, n), "w").write(src)
    print("\n".join(f"{n} {len(files[n])//1024}KB" for n in order))


STICKY2 = {
    "shift": "CaSe alterna mayúsculas y minúsculas, y la tecla que hace ese cambio es Shift. Su flecha además apunta hacia arriba: hacer crecer un negocio en la web.",
    "bezier": "La S de CaSe dibujada con la pluma de un programa de diseño: dos curvas, un punto de anclaje seleccionado en azul y su manejador. Diseño hecho con precisión.",
    "cristal": "El seleniuro de calcio (CaSe) cristaliza igual que la sal de mesa: calcio y selenio se alternan en una red cúbica, como se alternan mayúsculas y minúsculas en CaSe. Los puntos grandes son el selenio y los pequeños, el calcio: en el cristal, el ion de selenio mide casi el doble.",
    "switch": "En programación, cada «case» vive dentro de un «switch». Un interruptor encendido: CaSe enciende tu presencia en la web.",
    "pixel": "Una C armada en una cuadrícula de 3 × 3 píxeles. El último píxel en ponerse, arriba a la derecha, va en azul: se construye píxel a píxel.",
}

STICKY3 = {
    "escuadra": "La escuadra de dibujo, la herramienta de estudio para trazar bien. El ángulo recto queda abajo a la derecha, así que su borde largo sube como la barra de una dirección web.",
    "reticula": "En un estudio todo se alinea a una retícula. La C se traza sobre una cuadrícula de 4 × 4 y los puntos que no usa quedan a la vista. En tamaños pequeños queda solo la C.",
    "ion": "El calcio cede dos electrones y el selenio los recibe: así se forma CaSe. El calcio es el ion pequeño; el selenio, el anillo grande, con los dos electrones que acaba de recibir. Uno da y el otro recibe, como en una sociedad.",
    "lienzo": "Cada proyecto de un estudio empieza en una mesa de trabajo en blanco con su nombre arriba. El logo es ese lienzo, listo para lo que venga.",
    "pliegue": "Una sola cinta de papel doblada dos veces forma la S. Por delante en negro, por detrás en azul: dos caras del mismo material. Va con una serifa para darle oficio de estudio.",
}

STICKY4 = {
    "hex": "C, A, 5 y E son dígitos hexadecimales, así que #CA5E es un color válido en CSS: un dorado al 93 % de opacidad. El nombre del estudio es su propio color, y el símbolo es la muestra que un editor de código dibuja junto al valor.",
    "css": "Las mayúsculas de CaSe Studio son C, S y S: CSS, el lenguaje con el que se le da forma a la web. El logo es solo tipografía: las mayúsculas pesan y las minúsculas se aligeran para que la palabra aparezca.",
    "ranuras": "Un squircle con dos ranuras. La de arriba deja una C; las dos juntas, una S. Las dos iniciales en un solo bloque.",
    "plano": "El plano del estudio visto desde arriba: muros gruesos y la puerta abierta a la derecha. Los muros forman una C; la puerta y su giro van en azul.",
    "morse": "C, A, S y E en código Morse, una letra por fila. Puntos y rayas, encendido y apagado, como los bits.",
    "braille": "La palabra case en braille, con las proporciones del braille estándar. Una web bien hecha también se puede usar sin verla. La tipografía es Atkinson Hyperlegible, creada por el Braille Institute para leerse mejor.",
    "iman": "Un imán de herradura con forma de C y los polos en azul. Una buena web atrae clientes.",
    "volumen": "Una C cuadrada con profundidad: el frente en negro y el volumen en azul. Lo plano, llevado a tres dimensiones.",
    "ease": "Una curva ease-in-out, como las de las animaciones en CSS: arranca suave, acelera y llega suave. Tiene forma de S. El punto azul es lo que llega.",
    "mitades": "Dos medios círculos, uno por socio. El de arriba es una C; juntos dibujan una S.",
}

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "2"
    if which == "4":
        build(new4.CONCEPTS4, "studio2", "CaSe Studio 2", "s2", STICKY4, "/home/claude/case/logos/studio2", word2="Studio")
    elif which == "3":
        build(new3.CONCEPTS3, "studio", "CaSe Studio", "st", STICKY3, "/home/claude/case/logos/studio", word2="Studio")
    elif which == "1":
        build(new.CONCEPTS, "nuevos", "Nuevos diseños", "new", STICKY1, "/home/claude/case/logos/nuevos")
    else:
        build(new2.CONCEPTS2, "nuevos2", "Nuevos diseños 2", "n2", STICKY2, "/home/claude/case/logos/nuevos2")
