import sys
sys.path.insert(0, "/home/claude/case/tools")
import v2, new, new2, new3, new4
from textpath import font_file, metrics
INK, PAPER, BLUE = "#0A0A0A", "#FFFFFF", "#3355FF"
for fam in ("dm-mono","hanken-grotesk","outfit","work-sans","funnel-display","atkinson-hyperlegible","gabarito","unbounded","figtree","lexend"):
    print(fam, metrics(font_file(fam,400)))
def place(layers, W, H, x, y, size, fg):
    s = size / max(W, H)
    ox, oy = x + (size - W * s) / 2, y + (size - H * s) / 2
    return f'<g transform="translate({ox:.2f} {oy:.2f}) scale({s:.5f})">{v2.frag(layers, fg, BLUE)}</g>'
rows=[]; y=20
items = [(n, fn) for _, n, fn, _ in new4.CONCEPTS4] + [("css pequeño", new4.css_small), ("morse pequeño", new4.morse_small), ("braille pequeño", new4.braille_small)]
for name, fn in items:
    layers, W, H = fn()
    rows.append(f'<rect x="20" y="{y}" width="300" height="220" fill="{PAPER}"/>')
    rows.append(place(layers, W, H, 50, y + 20, 180 if W/H<1.6 else 240, INK))
    rows.append(f'<rect x="330" y="{y}" width="300" height="220" fill="{INK}"/>')
    rows.append(place(layers, W, H, 360, y + 20, 180 if W/H<1.6 else 240, PAPER))
    for i,sz in enumerate((64,32,16)):
        rows.append(place(layers, W, H, 650+[0,80,130][i], y+20, sz, INK))
        rows.append(place(layers, W, H, 650+[0,80,130][i], y+120, sz, PAPER) )
    rows.append(f'<rect x="645" y="{y+110}" width="170" height="80" fill="{INK}" opacity="1"/>')
    for i,sz in enumerate((64,32,16)):
        rows.append(place(layers, W, H, 650+[0,80,130][i], y+120, sz, PAPER))
    rows.append(f'<text x="830" y="{y+40}" font-family="sans-serif" font-size="14" fill="#555">{name}</text>')
    y+=240
svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="960" height="{y}"><rect width="100%" height="100%" fill="#ddd"/>{"".join(rows)}</svg>'
open('/home/claude/case/out/sheet8.svg','w').write(svg)
