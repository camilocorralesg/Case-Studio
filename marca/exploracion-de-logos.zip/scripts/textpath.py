"""Set text as outlined SVG paths (shaped with HarfBuzz, kerning included)."""
import io
import glob
import os
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

FONT_ROOT = "/home/claude/case/fonts"
_cache = {}


def font_file(family, weight, style="normal"):
    if isinstance(weight, tuple):
        weight, style = weight
    pat = os.path.join(FONT_ROOT, f"fontsource-{family}-[0-9]*", "package", "files",
                       f"{family}-latin-{weight}-{style}.woff")
    hits = glob.glob(pat)
    if not hits:
        raise FileNotFoundError(pat)
    return hits[0]


def _load(path):
    if path not in _cache:
        tt = TTFont(path)
        tt.flavor = None
        buf = io.BytesIO()
        tt.save(buf)
        data = buf.getvalue()
        tt = TTFont(io.BytesIO(data))
        face = hb.Face(data)
        font = hb.Font(face)
        _cache[path] = (tt, font, face.upem)
    return _cache[path]


def text_path(path, text, size, x=0.0, y=0.0, tracking=0.0, extra=None):
    """Return (d, width, (xmin, ymin, xmax, ymax)) for text with baseline at y.
    tracking is in em. extra: dict index->em of manual kerning after glyph i."""
    tt, font, upem = _load(path)
    buf = hb.Buffer()
    buf.add_str(text)
    buf.guess_segment_properties()
    hb.shape(font, buf, {"kern": True, "liga": False})
    gs = tt.getGlyphSet()
    order = tt.getGlyphOrder()
    s = size / upem
    pen_x = 0.0
    ds = []
    bxmin = bymin = 1e9
    bxmax = bymax = -1e9
    n = len(buf.glyph_infos)
    for i, (info, pos) in enumerate(zip(buf.glyph_infos, buf.glyph_positions)):
        name = order[info.codepoint]
        gx = x + (pen_x + pos.x_offset) * s
        gy = y - pos.y_offset * s
        sp = SVGPathPen(gs, ntos=lambda v: ('%.2f' % v).rstrip('0').rstrip('.'))
        tp = TransformPen(sp, (s, 0, 0, -s, gx, gy))
        gs[name].draw(tp)
        d = sp.getCommands()
        if d:
            ds.append(d)
            bp = BoundsPen(gs)
            gs[name].draw(bp)
            if bp.bounds:
                a, b, c, e = bp.bounds
                bxmin = min(bxmin, gx + a * s)
                bxmax = max(bxmax, gx + c * s)
                bymin = min(bymin, gy - e * s)
                bymax = max(bymax, gy - b * s)
        pen_x += pos.x_advance
        if i < n - 1:
            pen_x += tracking * upem
            if extra and i in extra:
                pen_x += extra[i] * upem
    width = pen_x * s
    return " ".join(ds), width, (bxmin, bymin, bxmax, bymax)


def metrics(path):
    tt, font, upem = _load(path)
    os2 = tt["OS/2"]
    return {"upem": upem, "cap": getattr(os2, "sCapHeight", 0) / upem,
            "xh": getattr(os2, "sxHeight", 0) / upem}
