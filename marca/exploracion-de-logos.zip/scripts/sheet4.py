import sys
sys.path.insert(0, "/home/claude/case/tools")
import v2
INK, PAPER, BLUE = "#0A0A0A", "#FFFFFF", "#3355FF"

def place(layers, W, H, x, y, size, fg):
    s = size / max(W, H)
    ox, oy = x + (size - W * s) / 2, y + (size - H * s) / 2
    return f'<g transform="translate({ox:.2f} {oy:.2f}) scale({s:.5f})">{v2.frag(layers, fg, BLUE)}</g>'

rows = []
y = 20
for kind, vs in v2.VARIANTS.items():
    x = 20
    for vid, name, fn in vs:
        layers, W, H = fn()
        rows.append(f'<rect x="{x}" y="{y}" width="200" height="300" fill="{PAPER}"/>')
        rows.append(place(layers, W, H, x + 30, y + 20, 140, INK))
        rows.append(f'<rect x="{x}" y="{y+180}" width="200" height="120" fill="{INK}"/>')
        rows.append(place(layers, W, H, x + 20, y + 200, 56, PAPER))
        rows.append(place(layers, W, H, x + 100, y + 212, 32, PAPER))
        rows.append(place(layers, W, H, x + 150, y + 220, 16, PAPER))
        rows.append(place(layers, W, H, x + 100, y + 260, 16, PAPER))
        rows.append(f'<text x="{x+6}" y="{y+176}" font-family="sans-serif" font-size="12" fill="#888">{name}</text>')
        x += 220
    y += 320
svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{20+5*220}" height="{y}"><rect width="100%" height="100%" fill="#ccc"/>{"".join(rows)}</svg>'
open("/home/claude/case/out/sheet4.svg", "w").write(svg)
