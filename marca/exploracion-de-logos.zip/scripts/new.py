"""Five new concepts. Each returns (layers, W, H); layer = (role, d[, transform]).
Roles: 'fg' ink/paper, 'accent' brand blue, 'bg' the ground colour (knocked-out detail),
'white' always white."""
import sys
sys.path.insert(0, "/home/claude/case/tools")
from marks import f
from textpath import font_file, text_path

SQ = "M{x} {y}h{w}v{h}h{mw}Z"


def rect(x, y, w, h):
    return f"M{f(x)} {f(y)}h{f(w)}v{f(h)}h{f(-w)}Z"


def rrect(x, y, w, h, r, ccw=False):
    """Rounded rectangle; ccw=True draws it the other way round (a hole under nonzero)."""
    if not ccw:
        return (f"M{f(x + r)} {f(y)}H{f(x + w - r)}A{f(r)} {f(r)} 0 0 1 {f(x + w)} {f(y + r)}"
                f"V{f(y + h - r)}A{f(r)} {f(r)} 0 0 1 {f(x + w - r)} {f(y + h)}H{f(x + r)}"
                f"A{f(r)} {f(r)} 0 0 1 {f(x)} {f(y + h - r)}V{f(y + r)}A{f(r)} {f(r)} 0 0 1 {f(x + r)} {f(y)}Z")
    return (f"M{f(x + r)} {f(y)}A{f(r)} {f(r)} 0 0 0 {f(x)} {f(y + r)}V{f(y + h - r)}"
            f"A{f(r)} {f(r)} 0 0 0 {f(x + r)} {f(y + h)}H{f(x + w - r)}A{f(r)} {f(r)} 0 0 0 {f(x + w)} {f(y + h - r)}"
            f"V{f(y + r)}A{f(r)} {f(r)} 0 0 0 {f(x + w - r)} {f(y)}Z")


# ------------------------------------------------------------ 1. Fórmula (Ca + Se)
FORM_FONT = "host-grotesk"


def formula(numbers=True, gap=8.0, ring=7.0, r=9.0):
    """Two periodic-table tiles: Ca (20) solid, Se (34) outlined."""
    T = 100.0
    sym = font_file(FORM_FONT, 600)
    num = font_file(FORM_FONT, 500)
    cap_ratio = 0.7  # Host Grotesk cap height ~0.7 em (checked in specimen)
    s_size = 40 / cap_ratio
    n_size = 14
    layers = []
    # tile 1: solid
    layers.append(("fg", rrect(0, 0, T, T, r)))
    d, _, _ = text_path(sym, "Ca", s_size, 14, 83, tracking=-0.02)
    layers.append(("bg", d))
    if numbers:
        d, _, _ = text_path(num, "20", n_size, 15, 27)
        layers.append(("bg", d))
    # tile 2: outline (ring made with opposite winding) + ink text
    x2 = T + gap
    ring_d = rrect(x2, 0, T, T, r) + rrect(x2 + ring, ring, T - 2 * ring, T - 2 * ring, max(r - ring, 1), ccw=True)
    layers.append(("fg", ring_d))
    d, _, _ = text_path(sym, "Se", s_size, x2 + 14, 83, tracking=-0.02)
    layers.append(("fg", d))
    if numbers:
        d, _, _ = text_path(num, "34", n_size, x2 + 15, 27)
        layers.append(("fg", d))
    return layers, 2 * T + gap, T


def formula_small(gap=8.0, ring=14.0, r=12.0):
    """Favicon form: the two tiles, no text."""
    T = 100.0
    x2 = T + gap
    return ([("fg", rrect(0, 0, T, T, r)),
             ("fg", rrect(x2, 0, T, T, r) + rrect(x2 + ring, ring, T - 2 * ring, T - 2 * ring, r * 0.4, ccw=True))],
            2 * T + gap, T)


def formula_icon():
    """App-icon form: Ca over Se, stacked, single solid tile split by a hairline gap."""
    sym = font_file(FORM_FONT, 600)
    size = 38
    d1, w1, _ = text_path(sym, "Ca", size, 15, 44, tracking=-0.02)
    d2, w2, _ = text_path(sym, "Se", size, 15, 84, tracking=-0.02)
    return [("fg", d1), ("fg", d2)], 100.0, 100.0


# ------------------------------------------------------------ 2. Caja alta (C a S e)
def caja_alta(B=44.0, s=28.0, g=8.0, r=6.0):
    """C a / S e: capitals as squares, lower case as circles sitting on the same baseline."""
    out = []
    for row in (0, 1):
        y = row * (B + g)
        out.append(rrect(0, y, B, B, r))
        cx, cy, rr = B + g + s / 2, y + B - s / 2, s / 2
        out.append(f"M{f(cx)} {f(cy - rr)}A{f(rr)} {f(rr)} 0 0 1 {f(cx)} {f(cy + rr)}"
                   f"A{f(rr)} {f(rr)} 0 0 1 {f(cx)} {f(cy - rr)}Z")
    return [("fg", "".join(out))], B + g + s, 2 * B + g


# ------------------------------------------------------------ 3. Marco (selection frame C)
def marco(t=6.5, hs=24.0, ring=6.0):
    """A design-tool selection frame with its right side left open: a C with four hollow
    handles. Frame lines stop at the handles."""
    S = 100.0
    c = hs / 2
    h = t / 2
    top = rect(hs, c - h, S - 2 * hs, t)
    bottom = rect(hs, S - c - h, S - 2 * hs, t)
    left = rect(c - h, hs, t, S - 2 * hs)
    handles = "".join(rrect(x, y, hs, hs, 3) + rrect(x + ring, y + ring, hs - 2 * ring, hs - 2 * ring, 0.8, ccw=True)
                      for x, y in ((0, 0), (S - hs, 0), (0, S - hs), (S - hs, S - hs)))
    return [("fg", top + bottom + left + handles)], S, S


# ------------------------------------------------------------ 4. Trazo (one line, C + S)
def trazo(t=16.0, R=20.0, Lc=24.0, Ls=19.0, space=10.0):
    h = t / 2
    yt, yb = h, h + 4 * R           # top and bottom centre lines
    cy = (yt + yb) / 2
    Rc = 2 * R
    cxC = Rc + h
    cxS = cxC + Lc + space + R + h
    W = cxS + R + h
    d = (f"M{f(cxC + Lc)} {f(yt - h)}H{f(cxC)}"
         f"A{f(Rc + h)} {f(Rc + h)} 0 0 0 {f(cxC)} {f(yb + h)}H{f(cxS)}"
         f"A{f(R + h)} {f(R + h)} 0 0 0 {f(cxS)} {f(cy - h)}"
         f"A{f(R - h)} {f(R - h)} 0 0 1 {f(cxS)} {f(yt + h)}H{f(cxS + Ls)}V{f(yt - h)}H{f(cxS)}"
         f"A{f(R + h)} {f(R + h)} 0 0 0 {f(cxS)} {f(cy + h)}"
         f"A{f(R - h)} {f(R - h)} 0 0 1 {f(cxS)} {f(yb - h)}H{f(cxC)}"
         f"A{f(Rc - h)} {f(Rc - h)} 0 0 1 {f(cxC)} {f(yt + h)}H{f(cxC + Lc)}Z")
    return [("fg", d)], W, yb + h


# ------------------------------------------------------------ 5. Corchetes ([ block ])
def corchetes(t=13.0, arm=24.0, block=30.0, r=4.0):
    S = 100.0
    left = f"M{f(arm)} 0H0V{f(S)}H{f(arm)}V{f(S - t)}H{f(t)}V{f(t)}H{f(arm)}Z"
    right = f"M{f(S - arm)} 0H{f(S)}V{f(S)}H{f(S - arm)}V{f(S - t)}H{f(S - t)}V{f(t)}H{f(S - arm)}Z"
    b0 = (S - block) / 2
    return [("fg", left + right), ("accent", rrect(b0, b0, block, block, r))], S, S


CONCEPTS = [
    ("formula", "Fórmula", formula, "host-grotesk"),
    ("caja-alta", "Caja alta", caja_alta, "familjen-grotesk"),
    ("marco", "Marco", marco, "onest"),
    ("trazo", "Trazo", trazo, "sora"),
    ("corchetes", "Corchetes", corchetes, "manrope"),
]
