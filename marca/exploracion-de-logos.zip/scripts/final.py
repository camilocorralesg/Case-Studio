"""Finalists: type and colour variations of Fórmula, Cristal, Braille and Morse for CaSe Studio.
Builds the canvas page 'Finalistas' (one Tipografías and one Colores artboard per logo)."""
import json
import os
import sys

sys.path.insert(0, "/home/claude/case/tools")
from marks import f
from new import rrect
from new2 import circle
from textpath import font_file, text_path, metrics

PROJ = "/home/claude/case/canvas/project"
WORD2 = "Studio"

# ------------------------------------------------------------------ palettes
# c1 colours the "Ca" half of the name, c2 the "Se" half.
SHARED = [
    dict(id="tinta", name="Tinta", bg="#FFFFFF", text="#0A0A0A", c1="#0A0A0A", c2="#0A0A0A"),
    dict(id="noche", name="Noche", bg="#0A0A0A", text="#FFFFFF", c1="#FFFFFF", c2="#FFFFFF"),
    dict(id="cobalto", name="Cobalto", bg="#FFFFFF", text="#0A0A0A", c1="#2B48FF", c2="#2B48FF"),
    dict(id="fondo-cobalto", name="Fondo cobalto", bg="#2B48FF", text="#FFFFFF", c1="#FFFFFF", c2="#FFFFFF"),
    dict(id="llama", name="Llama", bg="#FFFFFF", text="#0A0A0A", c1="#F0531C", c2="#1E6BFF"),
    dict(id="llama-noche", name="Llama de noche", bg="#0A0A0A", text="#FFFFFF", c1="#FF6A2B", c2="#3D82FF"),
    dict(id="oro", name="Oro #CA5E", bg="#0A0A0A", text="#FFFFFF", c1="#CCAA55", c2="#CCAA55"),
    dict(id="bicolor", name="Tinta y cobalto", bg="#FFFFFF", text="#0A0A0A", c1="#0A0A0A", c2="#2B48FF"),
]
SPECIAL = {
    "formula": dict(id="pizarra", name="Pizarra", bg="#22302A", text="#F2F2EC", c1="#F2F2EC", c2="#F2F2EC"),
    "cristal": dict(id="mineral", name="Mineral", bg="#0E1B2C", text="#EAF1FF", c1="#7FB0FF", c2="#EAF1FF"),
    "braille": dict(id="alto-contraste", name="Alto contraste", bg="#0A0A0A", text="#FFD60A", c1="#FFD60A", c2="#FFD60A"),
    "morse": dict(id="senal", name="Señal", bg="#0A0A0A", text="#FFFFFF", c1="#FFB000", c2="#FFB000"),
}

# ------------------------------------------------------------------ typefaces (family, label, heavy, light)
FONTS = {
    "formula": [("host-grotesk", "Host Grotesk", 600, 500), ("ibm-plex-sans", "IBM Plex Sans", 600, 500),
                ("instrument-sans", "Instrument Sans", 600, 500), ("manrope", "Manrope", 700, 500),
                ("sora", "Sora", 600, 400), ("ibm-plex-mono", "IBM Plex Mono", 600, 500)],
    "cristal": [("ibm-plex-sans", "IBM Plex Sans", 600, 400), ("host-grotesk", "Host Grotesk", 600, 400),
                ("instrument-sans", "Instrument Sans", 600, 400), ("onest", "Onest", 600, 400),
                ("schibsted-grotesk", "Schibsted Grotesk", 700, 400), ("jetbrains-mono", "JetBrains Mono", 700, 400)],
    "braille": [("atkinson-hyperlegible", "Atkinson Hyperlegible", 700, 400),
                ("atkinson-hyperlegible-next", "Atkinson Hyperlegible Next", 700, 400),
                ("lexend", "Lexend", 600, 300), ("inclusive-sans", "Inclusive Sans", 600, 400),
                ("readex-pro", "Readex Pro", 600, 300), ("figtree", "Figtree", 700, 400)],
    "morse": [("funnel-display", "Funnel Display", 600, 400), ("archivo", "Archivo", 700, 400),
              ("familjen-grotesk", "Familjen Grotesk", 600, 400), ("chivo", "Chivo", 700, 300),
              ("jetbrains-mono", "JetBrains Mono", 700, 400), ("unbounded", "Unbounded", 600, 300)],
}
CHOSEN = {"formula": 0, "cristal": 0, "braille": 0, "morse": 0}   # the typeface they picked
NAMES = {"formula": "Fórmula", "cristal": "Cristal", "braille": "Braille", "morse": "Morse"}


def P(d, fill):
    return f'<path fill="{fill}" d="{d}"></path>'


# ------------------------------------------------------------------ marks (colour-aware)
def formula_mark(fam, w_sym, pal):
    T, gap, r, ring = 100.0, 8.0, 9.0, 7.0
    sf = font_file(fam, w_sym)
    try:
        nf = font_file(fam, 500)
    except FileNotFoundError:
        nf = sf
    size = 40 / metrics(sf)["cap"]
    wmax = max(text_path(sf, t, size, 0, 0, tracking=-0.02)[1] for t in ("Ca", "Se"))
    if wmax > 70:
        size *= 70 / wmax
    x2 = T + gap
    out = [P(rrect(0, 0, T, T, r), pal["c1"])]
    out.append(P(text_path(sf, "Ca", size, 14, 83, tracking=-0.02)[0], pal["bg"]))
    out.append(P(text_path(nf, "20", 14, 15, 27)[0], pal["bg"]))
    ring_d = rrect(x2, 0, T, T, r) + rrect(x2 + ring, ring, T - 2 * ring, T - 2 * ring, r - ring, ccw=True)
    out.append(P(ring_d, pal["c2"]))
    out.append(P(text_path(sf, "Se", size, x2 + 14, 83, tracking=-0.02)[0], pal["c2"]))
    out.append(P(text_path(nf, "34", 14, x2 + 15, 27)[0], pal["c2"]))
    return "".join(out), 2 * T + gap, T, size


def cristal_mark(pal, big=13.5, small=7.5):
    out = []
    for i in range(3):
        for j in range(3):
            cx, cy = 14 + 36 * i, 14 + 36 * j
            if (i + j) % 2 == 0:
                out.append(P(circle(cx, cy, big), pal["c2"]))      # selenium: the large ion
            else:
                out.append(P(circle(cx, cy, small), pal["c1"]))    # calcium: the small ion
    return "".join(out), 100.0, 100.0


BRAILLE = {"c": (1, 4), "a": (1,), "s": (2, 3, 4), "e": (1, 5)}


def braille_mark(pal, word="case", a=2.5, pitch=6.0, r=0.98, s=10.0):
    pos = {1: (0, 0), 2: (0, 1), 3: (0, 2), 4: (1, 0), 5: (1, 1), 6: (1, 2)}
    out = []
    for i, ch in enumerate(word):
        col_key = "c1" if ch in "ca" else "c2"
        for d in BRAILLE[ch]:
            cx, cy = pos[d]
            out.append(P(circle((r + i * pitch + cx * a) * s, (r + cy * a) * s, r * s), pal[col_key]))
    return "".join(out), ((len(word) - 1) * pitch + a + 2 * r) * s, (2 * a + 2 * r) * s


MORSE = {"c": "-.-.", "a": ".-", "s": "...", "e": "."}


def morse_mark(pal, u=9.0, word="case"):
    out, width = [], 0.0
    for row, ch in enumerate(word):
        col = pal["c1"] if ch in "ca" else pal["c2"]
        x, y = 0.0, row * 2 * u
        for sym in MORSE[ch]:
            if sym == ".":
                out.append(P(circle(x + u / 2, y + u / 2, u / 2), col))
                x += u
            else:
                out.append(P(rrect(x, y, 3 * u, u, u / 2), col))
                x += 3 * u
            x += u
        width = max(width, x - u)
    return "".join(out), width, (len(word) - 1) * 2 * u + u


# ------------------------------------------------------------------ lockups
def lockup(kind, fam, w1, w2, pal):
    """Returns (svg fragment, width, height) in units where the cap height of the name is 100."""
    if kind == "formula":
        frag, W, H, size = formula_mark(fam, w1, pal)
        lf = font_file(fam, w2)
        d, w, _ = text_path(lf, WORD2, size, W + 17, 83, tracking=-0.02)
        cap = size * metrics(font_file(fam, w1))["cap"]
        k = 100 / cap
        out = f'<g transform="scale({k:.5f})">{frag}{P(d, pal["text"])}</g>'
        return out, (W + 17 + w) * k, H * k
    if kind == "cristal":
        frag, W, H = cristal_mark(pal)
        ratio, gapr = 1.42, 0.5
    elif kind == "braille":
        frag, W, H = braille_mark(pal)
        ratio, gapr = 1.0, 0.85
    else:
        frag, W, H = morse_mark(pal)
        ratio, gapr = 1.3, 0.42
    cap = 100.0
    hf, lf = font_file(fam, w1), font_file(fam, w2)
    size = cap / metrics(hf)["cap"]
    mh = cap * ratio
    s = mh / H
    mw = W * s
    gap = mh * gapr
    base = mh / 2 + cap / 2
    mono = "mono" in fam
    tr = -0.01 if mono else -0.025
    d1, wa, _ = text_path(hf, "CaSe", size, mw + gap, base, tracking=tr)
    sp = size * (0.6 if mono else 0.26)
    d2, wb, _ = text_path(lf, WORD2, size, mw + gap + wa + sp, base, tracking=tr)
    out = f'<g transform="scale({s:.5f})">{frag}</g>{P(d1, pal["text"])}{P(d2, pal["text"])}'
    return out, mw + gap + wa + sp + wb, mh


def svg_inline(frag, w, h, cap_px, label="CaSe Studio"):
    k = cap_px / 100.0
    return (f'<svg viewBox="0 0 {w:.2f} {h:.2f}" width="{w * k:.1f}" height="{h * k:.1f}" role="img" '
            f'aria-label="{label}" style="display: block">{frag}</svg>')


# ------------------------------------------------------------------ artboards
HEAD = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<style>
body{{margin:0}}
</style>
</helmet>
"""
TAIL = """</x-dc>
<script type="text/x-dc" data-dc-script data-props='{props}'>
class Component extends DCLogic {{
renderVals() {{
return {{}};
}}
}}
</script>
</body>
</html>
"""
CAP_TYPE = {"formula": 30, "cristal": 40, "braille": 40, "morse": 40}
CAP_COLOR = {"formula": 24, "cristal": 28, "braille": 26, "morse": 28}
LABEL = "font: 500 15px/1.3 system-ui, sans-serif; color: #5A5A5A; margin: 0"


def board(title, w, h, body):
    props = json.dumps({"$preview": {"width": w, "height": h}})
    return HEAD.format(title=title) + body + TAIL.format(props=props)


def types_board(kind):
    W, H = 1600, 1000
    cells = []
    tinta = SHARED[0]
    for fam, label, w1, w2 in FONTS[kind]:
        frag, lw, lh = lockup(kind, fam, w1, w2, tinta)
        cells.append(f'<div style="display: flex; flex-direction: column; justify-content: center; gap: 22px; '
                     f'border-top: 1px solid #E4E4E4; padding-top: 28px">\n{svg_inline(frag, lw, lh, CAP_TYPE[kind])}\n'
                     f'<p style="{LABEL}">{label}</p>\n</div>')
    body = (f'<div style="width: {W}px; height: {H}px; box-sizing: border-box; background: #FFFFFF; padding: 72px 96px; '
            f'display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); grid-template-rows: repeat(3, minmax(0, 1fr)); '
            f'column-gap: 96px; row-gap: 40px">\n' + "\n".join(cells) + "\n</div>\n")
    return board(f"{NAMES[kind]}: tipografías", W, H, body), W, H


def color_board(kind):
    W, H = 1600, 1010
    fam, label, w1, w2 = FONTS[kind][CHOSEN[kind]]
    cells = []
    for pal in SHARED + [SPECIAL[kind]]:
        frag, lw, lh = lockup(kind, fam, w1, w2, pal)
        border = "box-shadow: inset 0 0 0 1px #DEDEDE; " if pal["bg"].upper() == "#FFFFFF" else ""
        hexes = " / ".join(dict.fromkeys([pal["c1"], pal["c2"]]))
        cells.append(f'<div style="display: flex; flex-direction: column; gap: 12px">\n'
                     f'<div style="height: 236px; border-radius: 14px; {border}background: {pal["bg"]}; display: flex; '
                     f'align-items: center; justify-content: center">\n{svg_inline(frag, lw, lh, CAP_COLOR[kind])}\n</div>\n'
                     f'<p style="{LABEL}">{pal["name"]} · {hexes} sobre {pal["bg"]}</p>\n</div>')
    body = (f'<div style="width: {W}px; height: {H}px; box-sizing: border-box; background: #F3F3F3; padding: 64px; '
            f'display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); column-gap: 24px; row-gap: 26px; '
            f'align-content: start">\n' + "\n".join(cells) + "\n</div>\n")
    return board(f"{NAMES[kind]}: colores", W, H, body), W, H


STICKY = {
    "formula": "Las seis tipografías llevan las fichas y «Studio» a la misma altura de mayúscula. Para Llama: el calcio arde naranja y el selenio azul en la prueba de la llama, así que cada ficha lleva el color de su elemento.",
    "cristal": "En los colores, los puntos grandes son el selenio y los pequeños el calcio. En Llama cada uno lleva el color con el que arde su elemento.",
    "braille": "Las seis tipografías están pensadas para leerse mejor, en línea con la idea de accesibilidad. En los colores bicolores, las celdas de «ca» y de «se» llevan cada una su color.",
    "morse": "Las filas de C y A van en un color y las de S y E en otro cuando la paleta es bicolor. Señal usa el ámbar de una lámpara de señales.",
}


def build():
    files, boards, order, notes = {}, {}, [], {}
    ROW = 1450
    for r, kind in enumerate(["formula", "cristal", "braille", "morse"]):
        y0 = r * ROW
        src, w, h = types_board(kind)
        n1 = f"fin-{kind}-tipografias.dc.html"
        files[n1] = src
        boards[n1] = {"x": 0, "y": y0, "w": w, "h": h, "title": f"{NAMES[kind]} · tipografías", "page": "finalistas"}
        src, w2, h2 = color_board(kind)
        n2 = f"fin-{kind}-colores.dc.html"
        files[n2] = src
        boards[n2] = {"x": w + 80, "y": y0, "w": w2, "h": h2, "title": f"{NAMES[kind]} · colores", "page": "finalistas"}
        order += [n1, n2]
        notes[f"fint{r}"] = {"x": 0, "y": y0 - 300, "text": NAMES[kind], "kind": "title1", "maxW": w + 80 + w2,
                             "page": "finalistas"}
        notes[f"fins{r}"] = {"x": w + 80 + w2 + 80, "y": y0, "w": 380, "size": "l", "text": STICKY[kind],
                             "page": "finalistas"}
    canvas = json.load(open(os.path.join(PROJ, "canvas.json")))
    if not any(p["id"] == "finalistas" for p in canvas["pages"]):
        canvas["pages"].append({"id": "finalistas", "name": "Finalistas"})
    canvas["launch"] = {"view": "canvas", "page": "finalistas"}
    canvas["boards"].update(boards)
    canvas["order"] += [n for n in order if n not in canvas["order"]]
    canvas["notes"].update(notes)
    open(os.path.join(PROJ, "canvas.json"), "w").write(json.dumps(canvas, ensure_ascii=False, indent=1))
    for n, s in files.items():
        open(os.path.join(PROJ, n), "w").write(s)
    return order


if __name__ == "__main__":
    for n in build():
        print(n, len(open(os.path.join(PROJ, n)).read()) // 1024, "KB")
