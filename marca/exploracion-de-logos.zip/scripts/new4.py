"""CaSe Studio, second batch: ten concepts. Each returns (layers, W, H).
Roles: 'fg', 'accent', 'bg', 'white', and 'hex' (always #CA5E, the name as a CSS colour)."""
import math
import sys
sys.path.insert(0, "/home/claude/case/tools")
from marks import f
from new import rrect, rect
from new2 import circle, poly, stroke_bezier
from textpath import font_file, text_path
from shapely.geometry import Polygon, box, Point
from shapely.ops import unary_union


def shp_path(geom):
    """Shapely polygon(s) to an SVG path; holes keep the opposite winding (nonzero-safe)."""
    from shapely.geometry.polygon import orient
    geom = geom.simplify(0.03, preserve_topology=True)
    polys = [geom] if geom.geom_type == "Polygon" else list(geom.geoms)
    out = []
    for p in polys:
        p = orient(p, sign=-1.0)          # exterior clockwise on screen (y down)
        out.append(poly(list(p.exterior.coords)[:-1]))
        for ring in p.interiors:
            out.append(poly(list(ring.coords)[:-1]))
    return "".join(out)


def superellipse(cx, cy, a, b, n=5.0, k=360):
    pts = []
    for i in range(k):
        t = 2 * math.pi * i / k
        c, s = math.cos(t), math.sin(t)
        x = cx + a * math.copysign(abs(c) ** (2 / n), c)
        y = cy + b * math.copysign(abs(s) ** (2 / n), s)
        pts.append((x, y))
    return Polygon(pts)


def stadium(x0, x1, cy, h, round_left):
    """Horizontal slot from x0 to x1, rounded at one end."""
    r = h / 2
    if round_left:
        return unary_union([box(x0 + r, cy - r, x1, cy + r), Point(x0 + r, cy).buffer(r, 64)])
    return unary_union([box(x0, cy - r, x1 - r, cy + r), Point(x1 - r, cy).buffer(r, 64)])


# ---------------------------------------------------------------- 1. #CA5E
def hexcolor(r=18.0):
    """The name written as a CSS colour: #CA5E (C, A, 5, E are all hex digits) is a gold at
    93 % opacity. The mark is its swatch, as a code editor shows it next to the value."""
    return [("hex", rrect(0, 0, 100, 100, r))], 100.0, 100.0


# ---------------------------------------------------------------- 2. CSS
CSS_FONT = "hanken-grotesk"


def css_runs(text_runs, cap, x=0.0, base=None, heavy=800, light=300, tracking=-0.01):
    """Set alternating-weight runs. Returns (paths, width)."""
    fh = font_file(CSS_FONT, heavy)
    fl = font_file(CSS_FONT, light)
    from textpath import metrics
    size = cap / metrics(fh)["cap"]
    base = cap if base is None else base
    paths, pen = [], x
    for txt, w in text_runs:
        fp = fh if w == "h" else fl
        d, wd, _ = text_path(fp, txt, size, pen, base, tracking=tracking)
        if d:
            paths.append(d)
        pen += wd + size * tracking * 1000 / 1000
    return paths, pen - x


def css_mark():
    """For icons: the three capitals of CaSe Studio, which spell CSS."""
    paths, w = css_runs([("CSS", "h")], 70.0, 0, 70.0, tracking=-0.02)
    return [("fg", "".join(paths))], w, 70.0


def css_small():
    paths, w = css_runs([("C", "h")], 70.0, 0, 70.0)
    return [("fg", "".join(paths))], w, 70.0


# ---------------------------------------------------------------- 3. Ranuras
def ranuras(slot=17.0):
    """A squircle with two slots: the upper one leaves a C, both together leave an S."""
    body = superellipse(50, 50, 50, 50, n=4.6)
    up = stadium(27, 120, 33.5, slot, round_left=True)
    lo = stadium(-20, 73, 66.5, slot, round_left=False)
    g = body.difference(up).difference(lo)
    return [("fg", shp_path(g))], 100.0, 100.0


# ---------------------------------------------------------------- 4. Plano (floor plan)
def plano(t=13.0, a=36.0, b=74.0, leaf=4.6, arc_w=2.6):
    """The studio's floor plan: thick walls with the door open on the right, so the walls read
    as a C; the door leaf and its swing in the accent."""
    S = 100.0
    walls = poly([(0, 0), (S, 0), (S, a), (S - t, a), (S - t, t), (t, t), (t, S - t), (S - t, S - t),
                  (S - t, b), (S, b), (S, S), (0, S)])
    hx, hy = S - t, a
    L = b - a
    door = rect(hx - L, hy, L, leaf)
    # quarter-circle swing from the leaf tip to the closed position, drawn as a thin band
    outer, inner = [], []
    for i in range(61):
        ang = math.radians(180 - 90 * i / 60)
        outer.append((hx + (L + arc_w / 2) * math.cos(ang), hy + (L + arc_w / 2) * math.sin(ang)))
        inner.append((hx + (L - arc_w / 2) * math.cos(ang), hy + (L - arc_w / 2) * math.sin(ang)))
    swing = poly(outer + inner[::-1])
    return [("fg", walls), ("accent", door + swing)], S, S


# ---------------------------------------------------------------- 5. Morse
MORSE = {"c": "-.-.", "a": ".-", "s": "...", "e": "."}


def morse(u=9.0, rows="case"):
    """C, A, S, E in Morse code, one letter per row: dot 1 unit, dash 3, gaps 1."""
    paths = []
    width = 0.0
    for r, ch in enumerate(rows):
        x = 0.0
        y = r * 2 * u
        for k, sym in enumerate(MORSE[ch]):
            if sym == ".":
                paths.append(circle(x + u / 2, y + u / 2, u / 2))
                x += u
            else:
                paths.append(rrect(x, y, 3 * u, u, u / 2))
                x += 3 * u
            x += u
        width = max(width, x - u)
    H = (len(rows) - 1) * 2 * u + u
    return [("fg", "".join(paths))], width, H


def morse_small():
    return morse(rows="cs")


# ---------------------------------------------------------------- 6. Braille
BRAILLE = {"c": (1, 4), "a": (1,), "s": (2, 3, 4), "e": (1, 5)}


def braille(word="case", a=2.5, pitch=6.0, r=0.98):
    """The word case in braille, at true braille proportions (2.5 mm dot spacing, 6 mm cells)."""
    pos = {1: (0, 0), 2: (0, 1), 3: (0, 2), 4: (1, 0), 5: (1, 1), 6: (1, 2)}
    s = 10.0  # scale up
    paths = []
    for i, ch in enumerate(word):
        for d in BRAILLE[ch]:
            col, row = pos[d]
            paths.append(circle((r + i * pitch + col * a) * s, (r + row * a) * s, r * s))
    W = ((len(word) - 1) * pitch + a + 2 * r) * s
    H = (2 * a + 2 * r) * s
    return [("fg", "".join(paths))], W, H


def braille_small():
    return braille(word="cs")


# ---------------------------------------------------------------- 7. Imán (magnet)
def iman(t=31.0, pole=24.0, gap=3.0):
    """A horseshoe magnet shaped like a C: the poles in the accent. Good websites attract."""
    R = 50.0
    xb = 100 - pole - gap
    body = (f"M{f(xb)} 0H{f(R)}A{f(R)} {f(R)} 0 0 0 {f(R)} 100H{f(xb)}V{f(100 - t)}H{f(R)}"
            f"A{f(R - t)} {f(R - t)} 0 0 1 {f(R)} {f(t)}H{f(xb)}Z")
    poles = rect(100 - pole, 0, pole, t) + rect(100 - pole, 100 - t, pole, t)
    return [("fg", body), ("accent", poles)], 100.0, 100.0


# ---------------------------------------------------------------- 8. Volumen (extruded C)
def volumen(L=74.0, t=21.0, e=11.0):
    """A square C with real depth: the front in ink, the extrusion in the accent."""
    front = [(0, 0), (L, 0), (L, t), (t, t), (t, L - t), (L, L - t), (L, L), (0, L)]
    d = (e, -e)
    n = len(front)
    sides = []
    for i in range(n):
        p, q = front[i], front[(i + 1) % n]
        dx, dy = q[0] - p[0], q[1] - p[1]
        nx, ny = dy, -dx                     # outward normal for clockwise-on-screen order
        if nx * d[0] + ny * d[1] > 1e-9:
            sides.append([p, q, (q[0] + d[0], q[1] + d[1]), (p[0] + d[0], p[1] + d[1])])
    back = [(x + d[0], y + d[1]) for x, y in front]
    shift = lambda pts: [(x, y + e) for x, y in pts]
    depth = unary_union([Polygon(shift(back))] + [Polygon(shift(s)) for s in sides])
    return [("accent", shp_path(depth)), ("fg", poly(shift(front)))], L + e, L + e


# ---------------------------------------------------------------- 9. Ease (easing curve)
def ease(frame=5.5, w=11.0):
    """The ease-in-out curve from CSS: an S that starts slow, speeds up and lands softly.
    Drawn as the timing-function graph, with the moving object at the end in the accent."""
    fr = rrect(0, 0, 100, 100, 22) + rrect(frame, frame, 100 - 2 * frame, 100 - 2 * frame, 22 - frame, ccw=True)
    p0, p3 = (24.0, 76.0), (76.0, 24.0)
    p1 = (p0[0] + 0.65 * (p3[0] - p0[0]), p0[1])
    p2 = (p0[0] + 0.35 * (p3[0] - p0[0]), p3[1])
    curve = stroke_bezier(p0, p1, p2, p3, w)
    return [("fg", fr), ("fg", curve), ("fg", circle(*p0, w / 2)), ("accent", circle(*p3, w * 0.82))], 100.0, 100.0


# ---------------------------------------------------------------- 10. Mitades (two halves)
def mitades(R=27.0):
    """Two half circles, one per partner: the top one bulges left like a C, the bottom one
    right; together they draw an S."""
    H = 100.0
    cx = R
    top = (f"M{f(cx)} 0A{f(R)} {f(R)} 0 0 0 {f(cx)} {f(2 * R)}Z")
    bot = (f"M{f(cx)} {f(H - 2 * R)}A{f(R)} {f(R)} 0 0 1 {f(cx)} {f(H)}Z")
    return [("fg", top), ("accent", bot)], 2 * R, H


CONCEPTS4 = [
    ("hex", "#CA5E", hexcolor, "dm-mono"),
    ("css", "CSS", css_mark, "hanken-grotesk"),
    ("ranuras", "Ranuras", ranuras, "outfit"),
    ("plano", "Plano", plano, "work-sans"),
    ("morse", "Morse", morse, "funnel-display"),
    ("braille", "Braille", braille, "atkinson-hyperlegible"),
    ("iman", "Imán", iman, "gabarito"),
    ("volumen", "Volumen", volumen, "unbounded"),
    ("ease", "Ease", ease, "figtree"),
    ("mitades", "Mitades", mitades, "lexend"),
]
