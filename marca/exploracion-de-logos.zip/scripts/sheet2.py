import sys
sys.path.insert(0, "/home/claude/case/tools")
from lockup import lockup

combos = [
    ("dos", "onest", 600), ("dos", "mona-sans", 600), ("dos", "instrument-sans", 600),
    ("cursor", "instrument-sans", 600), ("cursor", "familjen-grotesk", 600), ("cursor", "schibsted-grotesk", 600),
    ("ruta", "schibsted-grotesk", 600), ("ruta", "host-grotesk", 600), ("ruta", "onest", 600),
]
rows = []
y = 30
for i, (k, fam, w) in enumerate(combos):
    frag, lw, lh = lockup(k, fam, w, x=40, y=y, uid=f"u{i}")
    rows.append(frag)
    frag2, lw2, _ = lockup(k, fam, w, text="CaSe", text2="Solutions", weight2=400, fill2="#6b6b6b",
                           x=40 + lw + 70, y=y, uid=f"v{i}")
    rows.append(frag2)
    rows.append(f'<text x="1180" y="{y+40}" font-family="sans-serif" font-size="13" fill="#888">{k} / {fam}</text>')
    y += lh + 40
svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="1360" height="{y}"><rect width="100%" height="100%" fill="#fff"/>{"".join(rows)}</svg>'
open("/home/claude/case/out/sheet2.svg", "w").write(svg)
