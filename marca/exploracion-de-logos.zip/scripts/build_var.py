"""Variation artboards: one row per direction (original + 4 variations) on a new canvas page."""
import json
import os
import sys

sys.path.insert(0, "/home/claude/case/tools")
import v2
from textpath import font_file, text_path, metrics

INK, PAPER, BLUE = "#0A0A0A", "#FFFFFF", "#3355FF"
ROOT = "/home/claude/case/canvas"
PROJ = os.path.join(ROOT, "project")
LOGOS = "/home/claude/case/logos/variaciones"
os.makedirs(LOGOS, exist_ok=True)

DIRS = {"dos": ("Dos piezas", "mona-sans", "dos-piezas"),
        "cursor": ("Cursor", "instrument-sans", "cursor"),
        "ruta": ("Ruta", "schibsted-grotesk", "ruta")}
CONTAINER = {("dos", "sello"), ("cursor", "seleccion")} | {("ruta", v[0]) for v in v2.VARIANTS["ruta"]}
W_AB, H_AB = 800, 600
TOP_H = 360


def closed(svg):
    return svg.replace('"/>', '"></path>')


def mark_svg(layers, W, H, size, fg, accent, label):
    """Inline SVG of the mark, longest side = size."""
    s = size / max(W, H)
    w, h = W * s, H * s
    return closed(f'<svg viewBox="0 0 {W:.2f} {H:.2f}" width="{w:.1f}" height="{h:.1f}" role="img" '
                  f'aria-label="{label}" style="display: block">{v2.frag(layers, fg, accent)}</svg>')


def lockup_frag(kind, layers, W, H, fg, accent, cap=100.0, container=False):
    fam = DIRS[kind][1]
    f6, f4 = font_file(fam, 600), font_file(fam, 400)
    mt = metrics(f6)
    size = cap / mt["cap"]
    mh = cap * 1.42
    s = mh / H
    mw = W * s
    gap = mh * (0.43 if container else 0.5)
    base = mh / 2 + cap / 2
    d1, w1, _ = text_path(f6, "CaSe", size, mw + gap, base, tracking=-0.025)
    sp = size * 0.26
    d2, w2, _ = text_path(f4, "Solutions", size, mw + gap + w1 + sp, base, tracking=-0.025)
    frag = (f'<g transform="scale({s:.5f})">{v2.frag(layers, fg, accent)}</g>'
            f'<path fill="{fg}" d="{d1}"/><path fill="{fg}" d="{d2}"/>')
    return frag, mw + gap + w1 + sp + w2, mh


def icon_svg(kind, vid, layers, W, H, size, accent):
    """App icon shown on the dark band: container marks are their own icon."""
    if (kind, vid) in CONTAINER:
        return mark_svg(layers, W, H, size, PAPER, accent, "Ícono de app")
    m = 0.62 if kind == "dos" else 0.56
    s = m * 100 / max(W, H) if kind != "dos" else m * 100 / H
    ox, oy = (100 - W * s) / 2, (100 - H * s) / 2
    inner = f'<g transform="translate({ox:.2f} {oy:.2f}) scale({s:.5f})">{v2.frag(layers, INK, accent)}</g>'
    return closed(f'<svg viewBox="0 0 100 100" width="{size}" height="{size}" role="img" aria-label="Ícono de app" '
                  f'style="display: block"><rect width="100" height="100" rx="22.5" fill="{PAPER}"></rect>{inner}</svg>')


HEAD = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<style>
body{{margin:0}}
</style>
</helmet>
"""
TAIL = """</x-dc>
<script type="text/x-dc" data-dc-script data-props='{props}'>
class Component extends DCLogic {{
renderVals() {{
return {{ {vals} }};
}}
}}
</script>
</body>
</html>
"""

files, boards, order, notes = {}, {}, [], {}
ROW = 1020
for r, (kind, variants) in enumerate(v2.VARIANTS.items()):
    dname, fam, dslug = DIRS[kind]
    y0 = r * ROW
    notes[f"vt{r}"] = {"x": 0, "y": y0 - 300, "text": f"{dname}: variaciones", "kind": "title1",
                       "maxW": 5 * W_AB + 4 * 80, "page": "variaciones"}
    for c, (vid, vname, fn) in enumerate(variants):
        layers, W, H = fn()
        uses_accent = any(l[0] == "accent" for l in layers)
        acc = "{{accent}}" if uses_accent else BLUE
        container = (kind, vid) in CONTAINER
        big = mark_svg(layers, W, H, 200, INK, acc, f"Símbolo {dname} {vname}")
        lf, lw, lh = lockup_frag(kind, layers, W, H, PAPER, acc, container=container)
        lock = closed(f'<svg viewBox="0 0 {lw:.2f} {lh:.2f}" width="330" height="{330 * lh / lw:.1f}" role="img" '
                      f'aria-label="CaSe Solutions" style="display: block">{lf}</svg>')
        icon = icon_svg(kind, vid, layers, W, H, 84, acc)
        fav = "".join(f'<div style="width: 32px; display: flex; justify-content: center">'
                      f'{mark_svg(layers, W, H, px, PAPER, acc, f"Favicon {px} px")}</div>' for px in (32, 16))
        body = f"""<div style="width: {W_AB}px; height: {H_AB}px; display: flex; flex-direction: column">
<div style="height: {TOP_H}px; background: {PAPER}; display: flex; align-items: center; justify-content: center">
{big}
</div>
<div style="flex-grow: 1; background: {INK}; display: flex; align-items: center; justify-content: space-between; padding: 0 56px">
{lock}
<div style="display: flex; align-items: center; gap: 24px">
{icon}
{fav}
</div>
</div>
</div>
"""
        props = {"$preview": {"width": W_AB, "height": H_AB}}
        vals = ""
        if uses_accent:
            props["accent"] = {"editor": "color", "default": BLUE, "options": [BLUE, "#FF5A1F", "#0E9F6E"],
                               "section": "Marca"}
            vals = f"accent: this.props.accent ?? '{BLUE}'"
        name = f"var-{dslug}-{vid}.dc.html"
        files[name] = (HEAD.format(title=f"{dname}: {vname}") + body +
                       TAIL.format(props=json.dumps(props, ensure_ascii=False), vals=vals))
        boards[name] = {"x": c * (W_AB + 80), "y": y0, "w": W_AB, "h": H_AB,
                        "title": f"{dname} · {vname}", "page": "variaciones"}
        order.append(name)
        # standalone files for later delivery
        sm = v2.frag(layers, INK, BLUE)
        open(f"{LOGOS}/{dslug}_{vid}_simbolo.svg", "w").write(
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.2f} {H:.2f}"><title>CaSe Solutions</title>{sm}</svg>')

canvas = json.load(open(os.path.join(PROJ, "canvas.json")))
canvas["pages"] = [{"id": "direcciones", "name": "Direcciones"}, {"id": "variaciones", "name": "Variaciones"}]
canvas["launch"] = {"view": "canvas", "page": "variaciones"}
canvas["boards"].update(boards)
canvas["order"] += [n for n in order if n not in canvas["order"]]
canvas["notes"].update(notes)
open(os.path.join(PROJ, "canvas.json"), "w").write(json.dumps(canvas, ensure_ascii=False, indent=1))
for n, src in files.items():
    open(os.path.join(PROJ, n), "w").write(src)
print("\n".join(order))
